# 🔐 Environment Variables Setup Guide

Complete guide for configuring environment variables for Snewroof Operations Portal.

---

## 📋 Table of Contents

1. [Quick Start](#quick-start)
2. [Required Variables](#required-variables)
3. [Optional Variables](#optional-variables)
4. [Security Best Practices](#security-best-practices)
5. [Common Issues](#common-issues)
6. [Troubleshooting](#troubleshooting)

---

## 🚀 Quick Start

### Option 1: Interactive Setup (Recommended)

```bash
# Run interactive setup script
bash scripts/setup-env.sh
```

The script will:
- ✅ Generate secure NEXTAUTH_SECRET
- ✅ Guide you through database selection
- ✅ Configure domain/URL
- ✅ Set up optional services (email, GHL)
- ✅ Create secure `.env` file

### Option 2: Manual Setup

```bash
# 1. Copy template
cp .env.production.example .env

# 2. Edit with your values
nano .env
# or
vim .env
```

### Option 3: Quick Development Setup

```bash
# Create minimal .env for development
cat > .env << 'EOF'
DATABASE_URL=file:./db/custom.db
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=$(openssl rand -base64 32)
NODE_ENV=development
PORT=3000
EOF
```

---

## ✅ Required Variables

### 1. DATABASE_URL

**What it is:** Connection string to your database

**SQLite (Development):**
```bash
DATABASE_URL="file:./db/custom.db"
```

**PostgreSQL (Production):**
```bash
DATABASE_URL="postgresql://username:password@host:5432/database"
```

**PostgreSQL with Supabase:**
```bash
DATABASE_URL="postgresql://postgres.[project-id]@[host].supabase.co:5432/postgres"
```

**Neon (Serverless PostgreSQL):**
```bash
DATABASE_URL="postgresql://[user]:[password]@[id].us-east-2.aws.neon.tech/neondb"
```

---

### 2. NEXTAUTH_URL

**What it is:** The base URL where your app is deployed

**Development:**
```bash
NEXTAUTH_URL="http://localhost:3000"
```

**Production (REQUIRED HTTPS):**
```bash
NEXTAUTH_URL="https://snewroof.yourdomain.com"
```

**Important Notes:**
- ⚠️ MUST use HTTPS in production
- ⚠️ Must NOT have trailing slash
- ⚠️ Must match exactly what users see in browser

---

### 3. NEXTAUTH_SECRET

**What it is:** Secret key for signing JWT tokens and encrypting sessions

**Requirements:**
- ✅ Minimum 32 characters
- ✅ Randomly generated
- ✅ Never shared publicly
- ✅ Never committed to Git

**Generate one:**
```bash
# Using OpenSSL (Recommended)
openssl rand -base64 32

# Using Node
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# Using Bun
bun -e "console.log(crypto.randomBytes(32).toString('base64'))"

# Or use the provided script
bash scripts/generate-secret.sh
```

**Example:**
```bash
NEXTAUTH_SECRET="XyZ9aBcDeF1gHiJkLmNoPqRsTuVwXyZ9aBcDeF1gH"
```

---

### 4. NODE_ENV

**What it is:** Application environment mode

**Values:**
- `development` - Development mode with debug info
- `production` - Production mode (optimized, no debug)
- `test` - Testing mode

**Setup:**
```bash
NODE_ENV="development"      # For local development
NODE_ENV="production"       # For production deployment
```

---

### 5. PORT

**What it is:** Port the application runs on

**Default:**
```bash
PORT="3000"
```

**Custom:**
```bash
PORT="8080"  # If using another port
```

---

## 🎛 Optional Variables

### Email/SMTP Configuration

Configure for sending email notifications, alerts, etc.

**Gmail Example:**
```bash
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_USER="your-email@gmail.com"
SMTP_PASSWORD="your-app-specific-password"  # Generate in Google Account > Security > App Passwords
SMTP_FROM="noreply@snewroof.com"
```

**SendGrid Example:**
```bash
SMTP_HOST="smtp.sendgrid.net"
SMTP_PORT="587"
SMTP_USER="apikey"
SMTP_PASSWORD="SG.xxxxxxxxxxxx"
SMTP_FROM="noreply@snewroof.com"
```

**Mailgun Example:**
```bash
SMTP_HOST="smtp.mailgun.org"
SMTP_PORT="587"
SMTP_USER="postmaster@snewroof.com"
SMTP_PASSWORD="your-mailgun-password"
SMTP_FROM="noreply@snewroof.com"
```

---

### GoHighLevel (GHL) Integration

Configure for syncing leads from CRM.

```bash
GHL_API_KEY="your-ghl-api-key"
GHL_LOCATION_ID="your-location-id"
```

**How to get credentials:**
1. Login to GoHighLevel
2. Go to Settings > Locations
3. Click API Settings
4. Copy API Key
5. Copy Location ID

---

### AWS S3 (File Storage)

Configure for backups, file uploads.

```bash
AWS_ACCESS_KEY_ID="AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_ACCESS_KEY="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
AWS_REGION="us-east-1"
AWS_S3_BUCKET="snewroof-backups"
```

**Setup AWS User:**
1. Go to AWS Console > IAM
2. Create new user with S3 access
3. Create access keys
4. Add credentials to .env

---

### Monitoring & Analytics

**Sentry (Error Tracking):**
```bash
NEXT_PUBLIC_SENTRY_DSN="https://key@org.sentry.io/project"
```

**Google Analytics:**
```bash
NEXT_PUBLIC_GA_ID="G-XXXXXXXXXX"
```

---

### CORS Configuration

Configure allowed origins for API access.

```bash
CORS_ORIGINS="https://snewroof.com,https://www.snewroof.com"
```

---

## 🔒 Security Best Practices

### 1. Generate Strong Secrets

```bash
# Use proper random generation
openssl rand -base64 32

# NOT these bad examples:
NEXTAUTH_SECRET="password123"           # ❌ Too simple
NEXTAUTH_SECRET="secret123"            # ❌ Too simple
NEXTAUTH_SECRET="my-secret-key"        # ❌ Not random
```

### 2. Never Commit .env Files

**Add to .gitignore:**
```gitignore
.env
.env.local
.env.production
.env.development
```

### 3. Use Environment-Specific Files

```bash
# Development
.env.development

# Production
.env.production

# Local overrides
.env.local
```

### 4. Secure File Permissions

```bash
# Restrict to owner only
chmod 600 .env

# Or use ACL for more control
setfacl -m u:rw .env
```

### 5. Rotate Secrets Regularly

**Schedule rotation:**
```bash
# Monthly rotation
0 0 1 * * /path/to/rotate-secrets.sh

# Quarterly rotation
0 0 1 1,4,7,10 * /path/to/rotate-secrets.sh
```

---

## ⚠️ Common Issues

### Issue: "NO_SECRET" Error

**Cause:** NEXTAUTH_SECRET not set or too short

**Solution:**
```bash
# Generate a proper secret
openssl rand -base64 32

# Add to .env
echo "NEXTAUTH_SECRET=\"$(openssl rand -base64 32)\"" >> .env

# Restart application
```

---

### Issue: Database Connection Fails

**Cause:** Incorrect DATABASE_URL

**Solution:**
```bash
# Test connection string
# For PostgreSQL:
psql "postgresql://user:pass@host:5432/db"

# For SQLite, ensure path is correct:
ls -la ./db/custom.db
```

---

### Issue: CORS Errors

**Cause:** NEXTAUTH_URL mismatch with actual URL

**Solution:**
```bash
# Ensure these match exactly:
# Browser URL:       https://snewroof.com
# NEXTAUTH_URL:      https://snewroof.com

# NOT different (trailing slash, http vs https)
# ❌ NEXTAUTH_URL="http://snewroof.com/"  (trailing slash)
# ❌ NEXTAUTH_URL="https://snewroof.com"  (different protocol)
```

---

### Issue: Email Not Sending

**Cause:** Incorrect SMTP credentials

**Solution:**
```bash
# For Gmail, generate App Password:
# 1. Google Account > Security
# 2. Enable 2-Step Verification
# 3. Generate App Password
# 4. Use App Password in .env

# Test SMTP connection:
telnet smtp.gmail.com 587
```

---

## 🔧 Troubleshooting

### Check Environment Variables

```bash
# List all environment variables
env | grep NEXTAUTH
env | grep DATABASE

# Check if .env is loaded
cat .env
```

### Test Configuration

```bash
# Test environment loading
curl http://localhost:3000/api/test

# Should return:
{
  "message": "API is working",
  "env": {
    "hasSecret": true,
    "hasUrl": true,
    "nodeEnv": "development"
  }
}
```

### Validate Secrets

```bash
# Check NEXTAUTH_SECRET length
echo $NEXTAUTH_SECRET | wc -c

# Should be at least 32 characters

# Check entropy (complexity)
# Higher is better
```

### Reset .env

```bash
# Start fresh (backup first!)
cp .env .env.backup
cp .env.production.example .env

# Edit new values
nano .env
```

---

## 📝 Environment Files Reference

### File Priority (when loading):

1. `.env.local` - Highest priority (not in Git)
2. `.env.production` - Production overrides
3. `.env.development` - Development overrides
4. `.env` - Default configuration

### When to use each:

| File | Use Case | Example |
|------|-----------|---------|
| `.env` | Local development | Default setup |
| `.env.local` | Local overrides, sensitive data | Personal API keys |
| `.env.development` | Dev environment config | Dev database URLs |
| `.env.production` | Production deployment | Production secrets |

---

## 🚢 Production Deployment

### Docker Environment Variables

```yaml
# docker-compose.yml
services:
  app:
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - NEXTAUTH_URL=${NEXTAUTH_URL}
      - NEXTAUTH_SECRET=${NEXTAUTH_SECRET}
      - NODE_ENV=production
```

### Cloud Platform Environment Variables

**Vercel:**
```bash
vercel env add NEXTAUTH_SECRET production
vercel env add DATABASE_URL production
```

**AWS Elastic Beanstalk:**
```bash
eb setenv NEXTAUTH_SECRET "your-secret" --environment production
eb setenv DATABASE_URL "your-db-url" --environment production
```

**DigitalOcean App Platform:**
- Use dashboard UI to set environment variables
- Or use CLI: `doctl apps create`

**Heroku:**
```bash
heroku config:set NEXTAUTH_SECRET="your-secret"
heroku config:set DATABASE_URL="your-db-url"
```

---

## 🎯 Quick Checklist

Before deploying:

- [ ] NEXTAUTH_SECRET generated (32+ chars)
- [ ] NEXTAUTH_URL set to production domain
- [ ] NEXTAUTH_URL uses HTTPS
- [ ] DATABASE_URL points to production DB
- [ ] NODE_ENV set to "production"
- [ ] SMTP configured (if using email)
- [ ] GHL configured (if using CRM)
- [ ] Optional services configured
- [ ] .env file has correct permissions (600)
- [ ] .env is NOT in Git
- [ ] Backup of secrets created
- [ ] Secrets stored in password manager

---

## 📚 Additional Resources

### Generate Secrets Online:
- https://generate-random.org/api-key-generator/
- https://www.random.org/strings/

### Environment Variable Managers:
- https://www.doppler.com/
- https://www.vaultproject.io/
- https://aws.amazon.com/secrets-manager/

### Security Best Practices:
- https://owasp.org/www-community/Securing_Critical_Assets
- https://cwe.mitre.org/

---

**Last Updated:** 2026  
**Version:** 1.0.0
