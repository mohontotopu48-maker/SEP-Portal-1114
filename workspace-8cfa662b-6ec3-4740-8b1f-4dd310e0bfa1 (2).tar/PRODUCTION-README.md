# Snewroof Operations & Monitoring Portal - Production Ready

> **Version**: 1.0.0 Production Ready
> **Status**: ✅ Ready for Deployment

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ or Bun 1.3+
- Docker & Docker Compose (recommended)
- 2GB+ RAM, 2+ CPU cores
- Domain name with SSL certificate

### One-Command Deployment (Docker)

```bash
# Clone repository
git clone <repository-url>
cd snewroof-portal

# Configure environment
cp .env.example .env
nano .env  # Update NEXTAUTH_SECRET and NEXTAUTH_URL

# Start all services
docker-compose up -d

# Access application
open http://your-domain.com
```

### Manual Deployment

```bash
# Install dependencies
bun install

# Setup database
bun run db:push

# Seed with sample data (optional)
bun run scripts/seed-db.ts

# Build application
bun run build

# Start production server
bun start
```

---

## 📋 Table of Contents

1. [Features](#features)
2. [Architecture](#architecture)
3. [Security](#security)
4. [Authentication](#authentication)
5. [Configuration](#configuration)
6. [Deployment](#deployment)
7. [Monitoring](#monitoring)
8. [Maintenance](#maintenance)
9. [Troubleshooting](#troubleshooting)

---

## ✨ Features

### Core Functionality

- **Authentication System**
  - NextAuth.js v4 with JWT sessions
  - Password hashing with bcryptjs
  - Role-based access control (RBAC)
  - Secure session management

- **Dashboard**
  - Real-time metrics and KPIs
  - Website status overview
  - Cost tracking and analysis
  - Task and alert summaries
  - Responsive design

- **Cost & Billing Manager**
  - Full CRUD operations
  - Monthly/yearly cost calculations
  - Vendor and category tracking
  - Due date and renewal management
  - Recurring payment indicators

- **Tools & API Manager**
  - Tool inventory management
  - Secure API key storage
  - Usage tracking with limits
  - Expiry date monitoring
  - Owner assignment

- **Website & Server Monitor**
  - Real-time uptime monitoring
  - SSL certificate tracking
  - Response time monitoring
  - Automatic health checks
  - Alert generation for downtime

- **User Management**
  - Role-based permissions (admin/manager/analyst)
  - User activation/deactivation
  - Activity logging

- **Alert System**
  - Multi-type alerts (website_down, cost_due, task_overdue, ssl_expiry)
  - Severity levels (info/warning/critical)
  - Read/unread tracking
  - Resolution management

---

## 🏗️ Architecture

### Technology Stack

```
Frontend:
├── Next.js 16 (App Router)
├── React 19
├── TypeScript 5
├── Tailwind CSS 4
├── shadcn/ui Components
└── Lucide Icons

Backend:
├── Next.js API Routes
├── Prisma ORM
├── SQLite (default) / PostgreSQL (optional)
├── NextAuth.js v4
├── bcryptjs (password hashing)
└── z-ai-web-dev-sdk (AI features)

Infrastructure:
├── Docker (containerization)
├── Nginx (reverse proxy)
├── Certbot (SSL certificates)
└── Health checks & monitoring
```

### Project Structure

```
/home/z/my-project/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── api/               # API routes
│   │   ├── dashboard/          # Dashboard components
│   │   ├── costs/              # Cost management
│   │   ├── tools/              # Tools management
│   │   ├── websites/           # Website monitoring
│   │   ├── login/              # Authentication
│   │   └── ...
│   ├── components/             # React components
│   │   ├── dashboard/
│   │   ├── ui/                # shadcn/ui
│   │   ├── providers/
│   │   └── sidebar.tsx
│   ├── lib/                   # Utilities
│   │   ├── auth/
│   │   ├── db.ts
│   │   └── utils.ts
│   ├── middleware.ts           # Route protection
│   └── types/                 # TypeScript types
├── prisma/
│   └── schema.prisma           # Database schema
├── mini-services/             # Microservices
│   └── website-monitor/       # Website monitoring service
├── scripts/                  # Utility scripts
│   ├── build.sh
│   └── seed-db.ts
├── Dockerfile                 # Main app container
├── docker-compose.yml         # Multi-service orchestration
├── .env.example             # Environment template
└── DEPLOYMENT.md           # Detailed deployment guide
```

---

## 🔒 Security

### Implemented Security Measures

1. **Authentication**
   - ✅ NextAuth.js with secure JWT sessions
   - ✅ Password hashing with bcryptjs (salt rounds: 10)
   - ✅ Secure cookie handling
   - ✅ Session token validation

2. **Access Control**
   - ✅ Role-based access control (RBAC)
   - ✅ Route protection via middleware
   - ✅ User activation/deactivation
   - ✅ Activity audit logging

3. **API Security**
   - ✅ Public routes whitelisting
   - ✅ Environment variable protection
   - ✅ CORS configuration
   - ✅ Health check endpoints

4. **Data Security**
   - ✅ Password hashing
   - ✅ Secure session storage
   - ✅ SQL injection prevention (Prisma ORM)
   - ✅ Input validation (Zod schemas)

5. **Infrastructure Security**
   - ✅ HTTPS enforced (SSL/TLS)
   - ✅ Firewall configuration
   - ✅ Docker container isolation
   - ✅ Non-root user execution

### Security Best Practices

```bash
# 1. Generate strong NEXTAUTH_SECRET
openssl rand -base64 32

# 2. Change default passwords immediately
# Admin: admin@snewroof.com / admin123 → CHANGE NOW
# Manager: manager@snewroof.com / manager123 → CHANGE NOW
# Analyst: analyst@snewroof.com / analyst123 → CHANGE NOW

# 3. Enable HTTPS
sudo certbot --nginx -d yourdomain.com

# 4. Configure firewall
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# 5. Regular updates
sudo apt update && sudo apt upgrade -y
```

### Security Checklist Before Production

- [ ] Change all default passwords
- [ ] Set strong NEXTAUTH_SECRET (32+ characters)
- [ ] Configure HTTPS with valid SSL
- [ ] Enable firewall rules
- [ ] Set up regular backups
- [ ] Configure log rotation
- [ ] Disable debug mode in production
- [ ] Review user permissions
- [ ] Test authentication flows
- [ ] Monitor security advisories

---

## 🔐 Authentication

### Default Credentials

⚠️ **WARNING**: Change these passwords immediately after first login!

| Role    | Email                  | Password    |
|----------|------------------------|-------------|
| Admin    | admin@snewroof.com    | admin123    |
| Manager  | manager@snewroof.com  | manager123  |
| Analyst  | analyst@snewroof.com  | analyst123  |

### User Roles

**Admin**: Full access to all features
- Create/edit/delete all resources
- Manage users and roles
- View all data and reports

**Manager**: Operational access
- Create/edit tasks and costs
- View reports and analytics
- Assign tasks to team members

**Analyst**: Read-only access
- View dashboard and reports
- Monitor website status
- View assigned tasks

### Changing Passwords

Currently, passwords are set in the seed script. To change passwords in production:

1. Access database directly
2. Update user password hash
3. Or implement password change feature

---

## ⚙️ Configuration

### Environment Variables

```bash
# Required
DATABASE_URL=file:./db/custom.db
NEXTAUTH_URL=https://yourdomain.com
NEXTAUTH_SECRET=<your-32-char-secret>
NODE_ENV=production

# Optional (for external services)
GHL_API_KEY=<go-highlevel-api-key>
GHL_LOCATION_ID=<location-id>

# Email/SMTP (for notifications)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM=noreply@snewroof.com
```

### Configuration Files

1. **`.env`** - Local development environment
2. **`.env.production`** - Production environment
3. **`.env.example`** - Template for new deployments
4. **`prisma/schema.prisma`** - Database schema
5. **`docker-compose.yml`** - Multi-service configuration

---

## 🚢 Deployment

### Option 1: Docker Deployment (Recommended)

```bash
# 1. Prepare environment
cp .env.example .env.production
nano .env.production

# 2. Build and start
docker-compose -f docker-compose.yml --env-file .env.production up -d

# 3. Verify
docker ps
curl http://localhost:3000/api/health

# 4. Configure Nginx (see DEPLOYMENT.md)
```

### Option 2: Manual Deployment

```bash
# 1. Install dependencies
bun install

# 2. Build application
bun run build

# 3. Setup database
bun run db:push

# 4. Seed data (optional)
bun run scripts/seed-db.ts

# 5. Start server
NODE_ENV=production bun start
```

### Option 3: Cloud Deployment

The application is compatible with:
- Vercel
- Railway
- DigitalOcean App Platform
- AWS ECS/Fargate
- Google Cloud Run

See provider-specific documentation for configuration details.

---

## 📊 Monitoring

### Health Check Endpoints

```bash
# Main application
curl https://your-domain.com/api/health

# Website monitor
curl http://localhost:3001/health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2026-02-02T12:00:00.000Z",
  "uptime": 3600.5,
  "environment": "production",
  "version": "1.0.0",
  "services": {
    "database": "healthy",
    "api": "healthy"
  }
}
```

### Monitoring Dashboard

Access the dashboard at `https://your-domain.com` after login:
- View real-time website status
- Monitor costs and tasks
- Check alerts and notifications
- Review system metrics

### Log Locations

```bash
# Docker logs
docker logs -f snewroof-app
docker logs -f snewroof-website-monitor

# Application logs
tail -f logs/app.log

# Database queries
# Logged in dev server logs (development only)
```

---

## 🛠️ Maintenance

### Database Operations

```bash
# Backup database
cp db/custom.db backups/custom-$(date +%Y%m%d-%H%M%S).db

# Restore database
cp backups/custom-20240202-120000.db db/custom.db

# Reset database (CAUTION)
bun run db:push --force-reset

# Re-seed after reset
bun run scripts/seed-db.ts
```

### Application Updates

```bash
# 1. Backup current data
cp db/custom.db backups/

# 2. Pull latest code
git pull origin main

# 3. Rebuild containers
docker-compose down
docker-compose build
docker-compose up -d

# 4. Verify deployment
curl https://your-domain.com/api/health
```

### Certificate Renewal

```bash
# Check certificate status
sudo certbot certificates

# Renew certificates
sudo certbot renew

# Test renewal
sudo certbot renew --dry-run
```

---

## 🐛 Troubleshooting

### Common Issues

**1. Authentication Not Working**
```bash
# Check NEXTAUTH_SECRET
echo $NEXTAUTH_SECRET

# Check environment loading
curl http://localhost:3000/api/test

# Clear NextAuth session
# Clear browser cookies and localStorage
```

**2. Database Connection Failed**
```bash
# Check database file permissions
ls -la db/custom.db

# Reset database
bun run db:push --force-reset
bun run scripts/seed-db.ts
```

**3. Website Monitor Not Responding**
```bash
# Check service status
docker ps | grep website-monitor

# Check logs
docker logs snewroof-website-monitor

# Restart service
docker restart snewroof-website-monitor
```

**4. High Memory Usage**
```bash
# Check container resources
docker stats

# Clean up Docker resources
docker system prune -a

# Restart containers
docker-compose restart
```

### Getting Help

1. Check logs: `docker logs snewroof-app`
2. Health check: `curl https://your-domain.com/api/health`
3. Documentation: `DEPLOYMENT.md`
4. Support team: support@snewroof.com

---

## 📈 Performance Optimization

### Database Optimization

- Add indexes to frequently queried fields
- Regular database maintenance
- Consider PostgreSQL for high-traffic deployments
- Implement connection pooling

### Application Optimization

- Enable response caching
- Use CDN for static assets
- Implement rate limiting
- Load balance multiple instances

### Monitoring

- Set up application performance monitoring
- Configure alerting for critical issues
- Track performance metrics
- Regular security audits

---

## 📝 Development vs Production

| Feature          | Development            | Production          |
|------------------|-----------------------|---------------------|
| Environment      | NODE_ENV=development | NODE_ENV=production |
| Database         | SQLite (local)       | PostgreSQL (recommended)|
| Logging          | Verbose              | Errors only          |
| HTTPS            | Optional             | Required            |
| Debug Mode       | Enabled              | Disabled            |
| Hot Reload       | Enabled              | Disabled            |

---

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Make changes and test
4. Submit pull request
5. Follow code style guidelines

---

## 📄 License

Proprietary - All rights reserved Snewroof

---

## 📞 Support

- **Documentation**: See `/docs` folder
- **Deployment Guide**: `DEPLOYMENT.md`
- **Issues**: Contact support team
- **Emergency**: Use health check endpoint

---

**Production Ready**: ✅
**Last Updated**: February 2026
**Maintained By**: Topon Mohonto
