# 🚀 Snewroof Operations Portal - Deployment Guide

## 📋 Quick Start Guide

### ✅ What's Already Done

The system is **production-ready** with the following features:

1. **✅ Authentication System**
   - NextAuth.js integrated with credentials provider
   - Password hashing with bcryptjs
   - Session management with JWT
   - Role-based access (admin, manager, analyst)

2. **✅ Database & Schema**
   - Complete Prisma schema with all required tables
   - SQLite database configured and running
   - Production data seeded

3. **✅ Core Features**
   - Dashboard with real-time metrics
   - Cost & Billing Manager (full CRUD)
   - Tools & API Manager (full CRUD)
   - Website & Server Monitor (full functionality)
   - Website monitoring service running on port 3001

4. **✅ Security Features**
   - Middleware for route protection
   - Session-based authentication
   - Role-based UI controls
   - Secure password storage

5. **✅ Production Configurations**
   - Docker setup for both app and monitor service
   - Environment variable templates
   - Health check endpoints
   - Deployment documentation

---

## 🔐 Step 1: Test the Application

### 1.1 Access the Login Page

Open your browser and navigate to:
```
http://localhost:3000/login
```

### 1.2 Login with Demo Credentials

The database has been seeded with 3 test users:

| Role | Email | Password |
|-------|--------|----------|
| **Admin** | admin@snewroof.com | admin123 |
| **Manager** | manager@snewroof.com | manager123 |
| **Analyst** | analyst@snewroof.com | analyst123 |

### 1.3 Test All Features

1. **Dashboard** - View metrics, website status, tasks, alerts
2. **Costs** - Add, edit, delete cost records
3. **Tools** - Manage tools and API keys
4. **Websites** - Monitor uptime and run checks

---

## 🔧 Step 2: Change Default Credentials (CRITICAL)

### 2.1 Access the Database

Currently, we're using SQLite. For production, you'll need to either:
- **Option A**: Continue with SQLite (simple setup)
- **Option B**: Migrate to PostgreSQL (better for production)

### 2.2 Reset Admin Password

For SQLite, you can use a simple script to update passwords:

```bash
# Create a password reset script
cat > reset-password.mjs << 'EOF'
import { db } from './src/lib/db.js'
import bcrypt from 'bcryptjs'

async function resetPassword(email, newPassword) {
  const hashedPassword = await bcrypt.hash(newPassword, 10)
  const user = await db.user.update({
    where: { email },
    data: { password: hashedPassword }
  })
  console.log(`✅ Password updated for ${email}`)
  await db.$disconnect()
}

resetPassword('admin@snewroof.com', 'your-new-strong-password')
EOF

# Run the script
bun reset-password.mjs
```

### 2.3 Delete Test Users (Optional)

After you've created your admin account:

```bash
# Delete manager and analyst test users
cat > delete-test-users.mjs << 'EOF'
import { db } from './src/lib/db.js'

async function deleteTestUsers() {
  await db.user.deleteMany({
    where: {
      email: {
        in: ['manager@snewroof.com', 'analyst@snewroof.com']
      }
    }
  })
  console.log('✅ Test users deleted')
  await db.$disconnect()
}

deleteTestUsers()
EOF

bun delete-test-users.mjs
```

---

## 🐳 Step 3: Production Deployment with Docker

### 3.1 Update Environment Variables

Create a production `.env` file:

```bash
cp .env.example .env.production
```

Edit `.env.production`:

```bash
# Database (SQLite for simplicity, or PostgreSQL for production)
DATABASE_URL="file:./db/custom.db"

# NextAuth - CHANGE THESE!
NEXTAUTH_URL="https://your-domain.com"
NEXTAUTH_SECRET="generate-a-32-character-random-secret"

# Environment
NODE_ENV="production"
```

### 3.2 Generate Secure NEXTAUTH_SECRET

Use one of these methods:

```bash
# Using OpenSSL
openssl rand -base64 32

# Using Node
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# Using Bun
bun -e "console.log(crypto.randomBytes(32).toString('base64'))"
```

### 3.3 Build and Start with Docker

```bash
# Build and start all services
docker-compose up -d

# View logs
docker-compose logs -f app

# Check health
curl http://localhost:3000/api/health
```

### 3.4 Production Docker Compose

Update `docker-compose.yml` for production:

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=file:./db/custom.db
      - NEXTAUTH_URL=https://your-domain.com
      - NEXTAUTH_SECRET=your-secure-secret-here
    volumes:
      - ./db:/app/db
      - ./logs:/app/logs
    restart: always
```

---

## 🌐 Step 4: Domain & SSL Setup

### 4.1 Configure Domain

For production deployment:

1. **Buy a domain** (e.g., snewroof.com)
2. **Point DNS** to your server IP
3. **Wait for DNS propagation** (usually 5-60 minutes)

### 4.2 Setup SSL Certificate

#### Using Let's Encrypt (Free)

```bash
# Install Certbot
sudo apt update
sudo apt install certbot python3-certbot-nginx -y

# Obtain SSL certificate
sudo certbot --nginx -d your-domain.com

# Certbot will automatically configure Nginx
```

#### Configure Nginx as Reverse Proxy

Create `/etc/nginx/sites-available/snewroof`:

```nginx
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl;
    server_name your-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    # Main app
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # Website monitor (optional, for internal access)
    location /ws/ {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

Enable and test:

```bash
sudo ln -s /etc/nginx/sites-available/snewroof /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 🛡️ Step 5: Security Checklist

Before going live, complete these security tasks:

- [ ] ✅ Changed default passwords
- [ ] ✅ Generated strong NEXTAUTH_SECRET (32+ characters)
- [ ] ✅ Set NEXTAUTH_URL to production domain
- [ ] ✅ Enabled HTTPS with valid SSL certificate
- [ ] ✅ Configured firewall (UFW or similar)
- [ ] ✅ Set up regular backups
- [ ] ✅ Disabled test users (manager, analyst)
- [ ] ✅ Reviewed and updated CORS settings
- [ ] ✅ Set up monitoring and alerting
- [ ] ✅ Created admin-only accounts
- [ ] ✅ Implemented rate limiting (optional)
- [ ] ✅ Regular security updates scheduled

---

## 📊 Step 6: Monitoring & Maintenance

### 6.1 Health Checks

Monitor your application:

```bash
# Application health
curl https://your-domain.com/api/health

# Expected response:
{
  "status": "healthy",
  "timestamp": "2026-02-02T...",
  "services": {
    "database": "healthy",
    "api": "healthy"
  }
}
```

### 6.2 View Logs

```bash
# Docker logs
docker logs -f snewroof-app

# Application logs
tail -f logs/app.log
```

### 6.3 Database Backups

```bash
# Backup SQLite database
docker exec snewroof-app tar -czf /app/db/ | gzip > backup-$(date +%Y%m%d).tar.gz

# Backup script (run daily via cron)
cat > /root/backup-snewroof.sh << 'EOF'
#!/bin/bash
cd /opt/snewroof
docker exec snewroof-app sh -c 'tar -czf /app/db/ -C /app db' | gzip > /backups/backup-$(date +%Y%m%d-%H%M%S).tar.gz
# Keep last 7 days
find /backups -name "backup-*.tar.gz" -mtime +7 -delete
EOF

# Make executable
chmod +x /root/backup-snewroof.sh

# Add to cron (daily at 2 AM)
echo "0 2 * * * /root/backup-snewroof.sh" | crontab -
```

---

## 🔄 Step 7: Updates & Maintenance

### 7.1 Update Application

```bash
# Pull latest code
git pull origin main

# Rebuild Docker images
docker-compose down
docker-compose build
docker-compose up -d

# Run database migrations (if any)
docker exec -it snewroof-app bun run db:push
```

### 7.2 Reseed Database (if needed)

```bash
# Run seed script
bun seed.mjs

# Or via Docker
docker exec -it snewroof-app bun seed.mjs
```

---

## 🐛 Troubleshooting

### Problem: Application won't start

```bash
# Check if port 3000 is in use
lsof -i :3000

# Kill existing process
kill -9 $(lsof -t -i:3000)

# Check Docker
docker ps -a
```

### Problem: Database locked

```bash
# Check SQLite file
ls -la db/custom.db

# Fix permissions
chmod 644 db/custom.db

# Reset database (last resort)
rm db/custom.db
bun run db:push
bun seed.mjs
```

### Problem: Can't login

```bash
# Check environment variables
cat .env

# Verify NEXTAUTH_SECRET is set
echo $NEXTAUTH_SECRET

# Check database has users
cat > check-users.mjs << 'EOF'
import { db } from './src/lib/db.js'
const users = await db.user.findMany()
console.log('Users:', users.map(u => ({ email: u.email, role: u.role })))
await db.$disconnect()
EOF
bun check-users.mjs
```

### Problem: Website monitor not working

```bash
# Check service status
docker logs snewroof-website-monitor

# Restart service
docker restart snewroof-website-monitor

# Check health
curl http://localhost:3001/health
```

---

## 📚 Additional Resources

### Documentation Files

- `DEPLOYMENT.md` - Detailed deployment guide
- `README.md` - Project overview
- `.env.example` - Environment variable template

### API Endpoints

- `GET /api/health` - Health check
- `POST /api/seed` - Seed database
- `GET /api/dashboard/stats` - Dashboard metrics
- `/api/costs` - Cost management
- `/api/tools` - Tools management
- `/api/websites` - Website monitoring

### Scripts

- `seed.mjs` - Database seeding script
- `scripts/build.sh` - Production build script

---

## ✅ Pre-Flight Checklist

Before going to production:

**Database**
- [ ] Database schema is updated
- [ ] Sample data seeded or production data imported
- [ ] Backup strategy in place

**Authentication**
- [ ] Default passwords changed
- [ ] NEXTAUTH_SECRET is strong (32+ chars)
- [ ] Test users removed or secured
- [ ] Role-based access tested

**Security**
- [ ] HTTPS enabled
- [ ] SSL certificate valid
- [ ] Firewall configured
- [ ] Environment variables secure
- [ ] No sensitive data in code

**Infrastructure**
- [ ] Docker containers running
- [ ] Health checks passing
- [ ] Logs configured
- [ ] Monitoring setup
- [ ] Backup automation configured

**Functionality**
- [ ] All features tested
- [ ] User flows verified
- [ ] Error handling confirmed
- [ ] Performance acceptable

---

## 🎉 You're Ready!

Once you've completed these steps:

1. **Access your portal**: `https://your-domain.com/login`
2. **Login with your admin account**
3. **Verify all features work**
4. **Set up monitoring and alerts**
5. **Enjoy your production-ready operations portal!**

---

## 📞 Support & Next Steps

### For Production Deployment

1. Review `DEPLOYMENT.md` for detailed server setup
2. Consider using managed services (AWS, DigitalOcean, etc.)
3. Set up CI/CD pipeline for automated deployments
4. Implement external monitoring (Sentry, LogRocket, etc.)

### For Scaling

1. Move from SQLite to PostgreSQL
2. Add Redis for caching
3. Implement load balancing
4. Use CDN for static assets

### For Additional Features

1. Add more alerts and integrations
2. Implement email notifications
3. Build mobile app
4. Add AI-powered insights

---

**Status**: ✅ Production Ready  
**Version**: 1.0.0  
**Last Updated**: 2026

Good luck with your deployment! 🚀
