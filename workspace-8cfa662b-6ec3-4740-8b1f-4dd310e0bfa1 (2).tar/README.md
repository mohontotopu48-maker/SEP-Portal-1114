# 🏢 Snewroof Operations Portal

A comprehensive, production-ready operations and monitoring portal built with Next.js 16, TypeScript, Prisma, and PostgreSQL.

## ✨ Features

### 🎯 Core Functionality
- **Dashboard** - Real-time metrics, website status, tasks, and alerts
- **Cost Management** - Track expenses, recurring bills, vendors
- **Tools & API Manager** - Manage tools, licenses, API keys securely
- **Website Monitoring** - Real-time uptime, SSL tracking, automatic alerts
- **Task Management** - Assign, track, and manage project tasks
- **Lead Management** - Track leads from GoHighLevel CRM
- **Alert System** - Customizable alerts for various events
- **Role-Based Access** - Admin, Manager, Analyst roles

### 🔐 Security Features
- Secure password hashing (bcryptjs)
- Session management with JWT
- Protected routes via middleware
- Role-based access control
- Environment-based configuration

### 🚀 Production Ready
- ✅ Vercel deployment configuration
- ✅ PostgreSQL database schema
- ✅ Docker configuration for self-hosting
- ✅ Health check endpoints
- ✅ Environment variable templates
- ✅ Complete deployment documentation

---

## 🚀 Quick Deploy to Vercel

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Create Vercel Postgres database
vercel postgres create

# 3. Update schema for PostgreSQL
cp prisma/schema.postgresql.prisma prisma/schema.prisma

# 4. Push to GitHub
git push origin main

# 5. Deploy to Vercel
vercel --prod

# 6. Configure environment variables at: https://vercel.com/dashboard
# Add DATABASE_URL, NEXTAUTH_URL, NEXTAUTH_SECRET
```

**See VERCEL_QUICK_START.md for detailed 5-minute deployment guide!**

---

## 📋 Quick Start

### Option 1: Vercel Deployment (Recommended)

See [VERCEL_QUICK_START.md](./VERCEL_QUICK_START.md) - Complete 5-minute guide

### Option 2: Docker Deployment

See [DEPLOYMENT.md](./DEPLOYMENT.md) - Detailed server deployment guide

### Option 3: Local Development

```bash
# Install dependencies
bun install

# Setup database
bun run db:push

# Seed with test data (optional)
bun seed.mjs

# Start development
bun run dev

# Access: http://localhost:3000/login

Default Credentials:
- Admin:    admin@snewroof.com / admin123
- Manager:  manager@snewroof.com / manager123
- Analyst:  analyst@snewroof.com / analyst123
```

---

## 📚 Documentation

| File | Purpose |
|------|---------|
| **[VERCEL_QUICK_START.md](./VERCEL_QUICK_START.md)** | 5-minute Vercel deployment |
| **[VERCEL_DEPLOYMENT.md](./VERCEL_DEPLOYMENT.md)** | Complete Vercel deployment guide |
| **[DEPLOYMENT.md](./DEPLOYMENT.md)** | Docker/server deployment |
| **[ENVIRONMENT.md](./ENVIRONMENT.md)** | Complete environment setup |
| **[QUICK_START.md](./QUICK_START.md)** | General deployment guide |
| **[PRODUCTION_READY.md](./PRODUCTION_READY.md)** | Production checklist |
| **[.env.vercel.example](./.env.vercel.example)** | Vercel environment template |
| **[REFERENCE.txt](./REFERENCE.txt)** | Quick reference card |

---

## 🏗 Project Structure

```
/home/z/my-project/
├── src/
│   ├── app/                    # Next.js App Router pages
│   │   ├── page.tsx           # Dashboard
│   │   ├── costs/              # Cost management
│   │   ├── tools/              # Tools & API management
│   │   ├── websites/           # Website monitoring
│   │   ├── login/              # Login page
│   │   └── api/                # API routes
│   ├── components/
│   │   ├── dashboard/          # Dashboard components
│   │   ├── sidebar.tsx         # Navigation sidebar
│   │   ├── providers/          # React providers
│   │   └── ui/                 # shadcn/ui components
│   ├── lib/
│   │   ├── auth/              # Authentication config
│   │   ├── db.ts             # Prisma client
│   │   └── utils.ts          # Utility functions
│   └── types/                 # TypeScript definitions
├── prisma/
│   ├── schema.prisma            # SQLite schema (default)
│   └── schema.postgresql.prisma # PostgreSQL schema (for Vercel)
├── mini-services/
│   └── website-monitor/        # Website monitoring service
├── scripts/
│   ├── build.sh               # Production build script
│   ├── setup-env.sh           # Environment setup script
│   └── generate-secret.sh     # Secret generator script
├── db/                        # SQLite database directory
├── Dockerfile               # Main application container
├── docker-compose.yml       # Full stack orchestration
├── vercel.json              # Vercel configuration
├── seed.mjs                 # Database seeding script
└── *.md                     # Documentation files
```

---

## 🔑 Authentication

### Roles

| Role | Permissions |
|------|------------|
| **Admin** | Full access to all features |
| **Manager** | Can view/edit costs, manage tasks |
| **Analyst** | View-only access to most data |

### Session Management

- JWT-based sessions
- Configurable timeout
- Secure password hashing
- Automatic session refresh

---

## 🗄 Database Schema

### Core Models

- **User** - Users with roles and passwords
- **Tool** - Tools, APIs, licenses, subscriptions
- **Cost** - Expenses, recurring bills
- **Project** - Project organization
- **Task** - Task management with assignments
- **Website** - Website monitoring
- **WebsiteCheck** - Check history
- **Lead** - CRM leads (GHL)
- **Alert** - System alerts
- **ActivityLog** - Audit trail

### Database Options

- **Development**: SQLite (file:./db/custom.db)
- **Vercel Production**: PostgreSQL (Vercel Postgres or Supabase)
- **Docker Production**: PostgreSQL or SQLite

---

## 🔌 API Endpoints

### Health & Status
- `GET /api/health` - Health check
- `GET /api/test` - Environment check

### Authentication
- `POST /api/auth/[...nextauth]` - NextAuth endpoints

### Dashboard
- `GET /api/dashboard/stats` - Dashboard metrics

### Costs
- `GET /api/costs` - List all costs
- `POST /api/costs` - Create cost
- `GET /api/costs/[id]` - Get cost
- `PATCH /api/costs/[id]` - Update cost
- `DELETE /api/costs/[id]` - Delete cost

### Tools
- `GET /api/tools` - List tools (basic)
- `GET /api/tools/full` - List tools (with details)
- `POST /api/tools/full` - Create tool
- `GET /api/tools/[id]` - Get tool
- `PATCH /api/tools/[id]` - Update tool
- `DELETE /api/tools/[id]` - Delete tool

### API Keys
- `GET /api/api-keys` - List API keys
- `POST /api/api-keys` - Create API key

### Websites
- `GET /api/websites` - List websites
- `POST /api/websites` - Add website
- `GET /api/websites/[id]` - Get website
- `PATCH /api/websites/[id]` - Update website
- `DELETE /api/websites/[id]` - Delete website
- `POST /api/websites/[id]/check` - Check individual website
- `POST /api/websites/check-all` - Check all websites

### Tasks
- `GET /api/tasks` - List tasks
- `POST /api/tasks` - Create task
- `GET /api/tasks/[id]` - Get task
- `PATCH /api/tasks/[id]` - Update task
- `DELETE /api/tasks/[id]` - Delete task

### Alerts
- `GET /api/alerts` - List alerts
- `PATCH /api/alerts` - Update alerts

### Users
- `GET /api/users` - List users

### Seed
- `POST /api/seed` - Seed database

---

## 🎨 Tech Stack

- **Framework**: Next.js 16 with App Router
- **Language**: TypeScript 5
- **Database**: Prisma ORM (SQLite or PostgreSQL)
- **Styling**: Tailwind CSS 4
- **UI Components**: shadcn/ui (New York style)
- **Icons**: Lucide React
- **Forms**: React Hook Form with Zod
- **Authentication**: NextAuth.js v4
- **State Management**: Zustand, TanStack Query
- **Password Hashing**: bcryptjs
- **Notifications**: Sonner

---

## 🚢 Deployment

### Vercel (Recommended - Easiest)

```bash
# Quick start: See VERCEL_QUICK_START.md
# Full guide: See VERCEL_DEPLOYMENT.md
vercel postgres create
cp prisma/schema.postgresql.prisma prisma/schema.prisma
git push origin main
vercel --prod
```

### Docker (Self-Hosted)

```bash
# Build and start
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

### Platform-Specific

- **Vercel**: See `VERCEL_DEPLOYMENT.md`
- **AWS**: See `DEPLOYMENT.md`
- **DigitalOcean**: See `DEPLOYMENT.md`
- **Railway**: See `DEPLOYMENT.md`

---

## 🔧 Development

### Available Scripts

```bash
# Development
bun run dev              # Start development server

# Database
bun run db:push          # Push schema to database
bun run db:generate      # Generate Prisma Client
bun run db:migrate       # Run migrations

# Production
bun run build           # Build for production
bun run start           # Start production server
bun run lint            # Run ESLint
```

### Custom Scripts

```bash
# Environment setup
bash scripts/setup-env.sh         # Interactive environment setup
bash scripts/generate-secret.sh   # Generate secure secret

# Database
bun seed.mjs                   # Seed database with test data
```

---

## 🔒 Security

- ✅ Password hashing with bcryptjs (cost factor: 10)
- ✅ JWT-based session management
- ✅ Protected routes via middleware
- ✅ Role-based access control
- ✅ Secure environment variable templates
- ✅ HTTPS enforcement in production

### Security Checklist

Before production:
- [ ] Generate secure NEXTAUTH_SECRET (32+ chars)
- [ ] Change all default passwords
- [ ] Use HTTPS for NEXTAUTH_URL
- [ ] Configure CORS properly
- [ ] Enable firewall rules
- [ ] Set up regular backups
- [ ] Monitor application logs
- [ ] Review audit trails

---

## 📊 Monitoring & Maintenance

### Health Checks

```bash
# Application health
curl http://localhost:3000/api/health

# Website monitor health
curl http://localhost:3001/health
```

### Logs

```bash
# Application logs
tail -f dev.log

# Docker logs
docker logs -f snewroof-app
docker logs -f snewroof-website-monitor
```

### Backups

```bash
# Backup database
cp db/custom.db backups/custom-$(date +%Y%m%d).db

# Automated backup (add to cron)
0 2 * * * /path/to/backup-script.sh
```

---

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

---

## 📄 License

This project is proprietary and confidential.

---

## 📞 Support

For deployment issues:
1. Check [VERCEL_QUICK_START.md](./VERCEL_QUICK_START.md) - 5-minute guide
2. Review [VERCEL_DEPLOYMENT.md](./VERCEL_DEPLOYMENT.md) - Full Vercel guide
3. Check [ENVIRONMENT.md](./ENVIRONMENT.md) - Environment setup
4. Check application logs
5. Verify environment variables

---

## 🎉 Version History

**v1.0.0** - February 2026
- Initial production-ready release
- Complete authentication system
- Full feature implementation
- Docker configuration
- Complete Vercel deployment configuration
- Comprehensive documentation

---

**Status**: ✅ Vercel Ready  
**Version**: 1.0.0  
**Last Updated**: 2026

Built with ❤️ for Snewroof
