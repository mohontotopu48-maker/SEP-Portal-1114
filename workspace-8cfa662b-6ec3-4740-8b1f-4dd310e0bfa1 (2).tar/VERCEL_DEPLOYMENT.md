# 🚀 Snewroof Operations Portal - Vercel Deployment Guide

Complete guide for deploying to Vercel with PostgreSQL database.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Database Setup](#database-setup)
3. [Vercel Configuration](#vercel-configuration)
4. [Environment Variables](#environment-variables)
5. [Deploy to Vercel](#deploy-to-vercel)
6. [Post-Deployment](#post-deployment)
7. [Troubleshooting](#troubleshooting)

---

## ✅ Prerequisites

### Requirements

- ✅ Vercel Account (Free: https://vercel.com/signup)
- ✅ GitHub Account
- ✅ Node.js 18+ or Bun
- ✅ Project code committed to Git

### Create Accounts

```bash
# 1. Sign up for Vercel
# Visit: https://vercel.com/signup

# 2. Create GitHub repository
# Visit: https://github.com/new
# Initialize repository with your project
```

---

## 🗄 Database Setup

### Option 1: Vercel Postgres (Recommended)

**Why Vercel Postgres?**
- Free 256MB storage
- Built-in connection pooling
- Direct Vercel integration
- Automatic scaling

**Setup Steps:**

1. **Create Vercel Postgres Database**
   ```bash
   # Using Vercel CLI
   vercel postgres create

   # Or via Dashboard:
   # 1. Go to: https://vercel.com/dashboard
   # 2. Select your project
   # 3. Go to: Storage > Vercel Postgres
   # 4. Click "Create Database"
   # 5. Choose a name (e.g., snewroof-db)
   # 6. Click "Continue"
   ```

2. **Get Connection String**
   ```bash
   # Via CLI
   vercel postgres ls

   # Via Dashboard:
   # 1. Go to Storage > Vercel Postgres
   # 2. Click on your database
   # 3. Click ".env" button
   # 4. Copy DATABASE_URL
   ```

**Example Connection String:**
```
postgresql://default:[password]@ep-xyz.aws.us-east-1.aws.com:5432/vercel-db?sslmode=require
```

### Option 2: Supabase (Alternative)

**Why Supabase?**
- Free 500MB storage
- 1GB bandwidth/month
- Built-in authentication
- PostgreSQL compatible

**Setup Steps:**

1. **Create Project**
   ```
   Visit: https://supabase.com
   Click: "Start your project"
   ```

2. **Get Connection String**
   ```
   Project Settings > Database > Connection String
   Example: postgresql://postgres.[project-id]@[host].supabase.co:5432/postgres
   ```

### Option 3: Neon (Serverless)

**Why Neon?**
- Free 0.5GB storage
- Serverless PostgreSQL
- Auto-scaling
- Vercel compatible

**Setup Steps:**

1. **Create Project**
   ```
   Visit: https://neon.tech
   Create project: snewroof-portal
   ```

2. **Get Connection String**
   ```
   Dashboard > Connection Details
   Example: postgresql://[user]:[password]@[id].us-east-2.aws.neon.tech/neondb
   ```

---

## 🔧 Vercel Configuration

### Install Vercel CLI

```bash
# Using npm
npm i -g vercel

# Using Bun
bun install -g vercel

# Or using npx
npx vercel@latest login
```

### Login to Vercel

```bash
vercel login
```

### Initialize Project

```bash
# From project root
vercel

# Follow prompts:
# 1. Set up and deploy? Y
# 2. Link to existing project? (if you have one)
# 3. Project name: snewroof-portal
# 4. Directory: . (current directory)
# 5. Override settings? N
```

---

## 🔐 Environment Variables

### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://...` |
| `NEXTAUTH_URL` | Your Vercel domain (HTTPS) | `https://snewroof-portal.vercel.app` |
| `NEXTAUTH_SECRET` | JWT signing secret (32+ chars) | Generate with OpenSSL |
| `NODE_ENV` | Environment mode | `production` |

### Add Variables to Vercel

**Via Vercel Dashboard:**
```
1. Go to: Project > Settings > Environment Variables
2. For each variable:
   a. Enter Name (e.g., DATABASE_URL)
   b. Enter Value
   c. Select environments: Production, Preview, Development
   d. Click "Save"
```

**Via Vercel CLI:**
```bash
# Add single variable
vercel env add DATABASE_URL "postgresql://..." production

# Add all at once
vercel env pull .env.local
vercel env push .env.local production
```

### Generate NEXTAUTH_SECRET

```bash
# Using OpenSSL (Recommended)
openssl rand -base64 32

# Using Node
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# Using Bun
bun -e "console.log(crypto.randomBytes(32).toString('base64'))"
```

**⚠️ CRITICAL: NEXTAUTH_SECRET must be 32+ random characters!**

---

## 🚀 Deploy to Vercel

### Option 1: GitHub Integration (Recommended)

**Steps:**

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Connect GitHub to Vercel**
   ```
   a. Go to: https://vercel.com/new
   b. Click "Import Git Repository"
   c. Select your repository
   d. Configure framework: Next.js
   e. Root directory: `./` or leave empty
   f. Click "Deploy"
   ```

3. **Automatic Deployments**
   - Vercel auto-deploys on every git push
   - Each branch gets its own preview URL
   - Main branch gets production URL

**Preview URLs:**
```
Main: https://snewroof-portal.vercel.app
Branch: https://snewroof-portal-git-branch.vercel.app
Pull Request: https://snewroof-portal-pr-123.vercel.app
```

### Option 2: Direct Deployment

```bash
# From project root
vercel --prod

# Follow prompts:
# 1. Link to existing project
# 2. Select environment: Production
# 3. Deploy
```

---

## 📝 Migrate Database Schema

### Update to PostgreSQL

```bash
# 1. Backup PostgreSQL schema (already provided)
# 2. Replace schema in prisma/schema.prisma

# Option A: Use PostgreSQL for production only
# Keep SQLite for local development

# Option B: Use PostgreSQL everywhere
# 1. cp prisma/schema.postgresql.prisma prisma/schema.prisma
# 2. Update .env to use PostgreSQL
```

### Update .env for PostgreSQL

```bash
# Development (with PostgreSQL)
DATABASE_URL="postgresql://localhost:5432/snewroof?user=postgres&password=postgres"

# Production (Vercel Postgres)
DATABASE_URL="postgresql://default:[password]@[host].prisma-data.net:5432/vercel-db?sslmode=require"
```

---

## 🗄 Database Migration

### Step 1: Push Schema to Database

```bash
# Generate Prisma Client with PostgreSQL schema
bun run db:generate

# Push schema to PostgreSQL
bun run db:push
```

### Step 2: Migrate Data (if needed)

```bash
# Use Prisma Migrate for production
bun run db:migrate

# Or use seed script
# Note: Update seed.mjs for PostgreSQL connection string
bun seed.mjs
```

---

## 🚀 Deploy Process

### Complete Deployment Steps

```bash
# 1. Ensure project is committed
git add .
git commit -m "Ready for Vercel deployment"

# 2. Push to GitHub
git push origin main

# 3. Vercel will auto-deploy
# Monitor at: https://vercel.com/dashboard

# 4. Wait for deployment (~1-2 minutes)
# Check deployment logs in Vercel dashboard
```

### Manual Deploy (if needed)

```bash
# Deploy to production
vercel --prod

# Deploy to preview
vercel
```

---

## ✅ Post-Deployment

### Step 1: Verify Deployment

```bash
# Check application
curl https://your-project.vercel.app/api/health

# Expected response:
{
  "status": "healthy",
  "timestamp": "2026-02-02T...",
  "services": {
    "database": "healthy",
    "api": "healthy"
  }
}
```

### Step 2: Seed Database (First Time Only)

```bash
# Create migration/seed script for Vercel
cat > scripts/vercel-seed.mjs << 'EOF'
import { db } from "../prisma/postgres/lib/index.js"
import bcrypt from "bcryptjs"

async function seed() {
  console.log("🌱 Seeding production database...")

  // Your seeding logic here
  // Same as seed.mjs but with PostgreSQL

  await db.$disconnect()
}

seed()
EOF

# Execute
bun scripts/vercel-seed.mjs
```

### Step 3: Create Admin User

```bash
# Access the application
https://your-project.vercel.app/login

# Use admin account or create new one
```

### Step 4: Test All Features

- [ ] Dashboard loads and shows metrics
- [ ] Login works with credentials
- [ ] Cost management CRUD operations
- [ ] Tools management CRUD operations
- [ ] Website monitoring displays status
- [ ] API endpoints are accessible
- [ ] Health check returns healthy

---

## 🛠️ Troubleshooting

### Build Failures

**Issue: Build timeout (60s limit)**
```
Solution:
1. Optimize build time
2. Reduce dependencies
3. Use Vercel build caching
```

### Runtime Errors

**Issue: Database connection failed**
```
Solution:
1. Verify DATABASE_URL in Vercel environment variables
2. Check Vercel Postgres is active
3. Test connection: vercel env pull
4. Check Vercel logs for detailed errors
```

**Issue: NEXTAUTH_SECRET not set**
```
Solution:
1. Check environment variables in Vercel dashboard
2. Ensure NEXTAUTH_SECRET is 32+ characters
3. Re-deploy after adding
4. Check Vercel logs
```

### Deployment Issues

**Issue: Deployment fails**
```
Solution:
1. Check Next.js version compatibility
2. Review build logs in Vercel dashboard
3. Ensure all dependencies in package.json
4. Try clearing build cache: vercel build --force
```

### Function Timeouts

**Issue: API functions timeout (60s limit)**
```
Solution:
1. Optimize database queries
2. Add proper indexes
3. Break long operations into smaller chunks
4. Consider using Vercel Edge Functions for static endpoints
```

---

## 📊 Vercel Limits (Free Tier)

| Resource | Limit | Notes |
|----------|-------|-------|
| Build Time | 60s | Serverless Functions |
| Function Execution | 60s | Per invocation |
| Bandwidth | 100GB/month | Total transfer |
| Serverless Functions | 100GB-hours/month | CPU time |
| Vercel Postgres | 256MB | Storage |
| Team Members | Unlimited | Free tier |
| Domains | Unlimited | Custom domains |

### Upgrade Plans

- **Pro**: $20/month - More bandwidth, priority support
- **Enterprise**: Custom - Unlimited resources, SLA

---

## 🔒 Security for Vercel

### Environment Variables Security

- ✅ Variables encrypted at rest
- ✅ Never log or expose in client code
- ✅ Use Vercel dashboard for management
- ✅ Don't commit .env files

### HTTPS Enforcement

- ✅ Vercel automatically provides HTTPS
- ✅ No HTTP to HTTPS redirects needed
- ✅ SSL certificates managed by Vercel

### Secrets Management

```bash
# List secrets (CLI)
vercel env ls

# Pull secrets locally
vercel env pull

# Remove secret
vercel env rm NEXTAUTH_SECRET production
```

---

## 📱 Preview Deployments

### Branch Deployments

Each git branch gets its own preview URL:

```bash
# Create feature branch
git checkout -b feature/new-dashboard

# Make changes
git commit -am "Add new dashboard features"
git push origin feature/new-dashboard

# Preview URL
https://snewroof-portal-git-feature-new-dashboard.vercel.app
```

### Pull Request Deployments

Each PR gets preview URL for testing:

```
https://snewroof-portal-pr-123.vercel.app
```

---

## 🔄 Updates & Maintenance

### Continuous Deployment

```bash
# Workflow:
1. Make changes locally
2. Test locally: bun run dev
3. Commit changes: git commit -am "Update feature"
4. Push: git push origin main
5. Vercel auto-deploys
```

### Rollback Deployment

```bash
# Via Vercel Dashboard:
# 1. Go to Deployments
# 2. Find previous deployment
# 3. Click "Promote to Production"
```

---

## 📚 Additional Resources

### Vercel Documentation

- [Getting Started](https://vercel.com/docs)
- [Next.js on Vercel](https://vercel.com/docs/frameworks/nextjs)
- [Vercel Postgres](https://vercel.com/docs/storage/vercel-postgres)
- [Environment Variables](https://vercel.com/docs/projects/environment-variables)
- [Deployments](https://vercel.com/docs/deployments/overview)

### Useful Guides

- [NextAuth.js with Vercel](https://next-auth.js.org/providers/credentials#vercel-provider)
- [Prisma with PostgreSQL](https://www.prisma.io/docs/concepts/database-connectors/postgresql)
- [Vercel CLI](https://vercel.com/docs/cli)

---

## ✅ Deployment Checklist

Before deploying:

**Database:**
- [ ] Vercel Postgres database created
- [ ] DATABASE_URL copied from Vercel dashboard
- [ ] Prisma schema updated for PostgreSQL
- [ ] Schema pushed to database: `bun run db:push`
- [ ] Database seeded with initial data

**Environment:**
- [ ] NEXTAUTH_URL set to Vercel domain (HTTPS!)
- [ ] NEXTAUTH_SECRET generated (32+ chars)
- [ ] NEXTAUTH_SECRET added to Vercel environment
- [ ] NODE_ENV set to "production"
- [ ] All required variables added to Vercel

**Code:**
- [ ] All changes committed to Git
- [ ] Git repository pushed to GitHub
- [ ] Repository connected to Vercel
- [ ] No .env files in repository
- [ ] Production build tested locally

**Security:**
- [ ] Default passwords changed
- [ ] Test users removed
- [ ] HTTPS enabled (automatic with Vercel)
- [ ] Secrets not exposed in client code

**Testing:**
- [ ] Preview deployment tested
- [ ] All features working in preview
- [ ] API endpoints accessible
- [ ] Database queries optimized

**Deployment:**
- [ ] Vercel project created/imported
- [ ] Deployment to production successful
- [ ] Health check passing
- [ ] Application URL accessible

---

## 🎉 You're Deployed!

Your Snewroof Operations Portal is now live on Vercel!

**Access Your Portal:**
```
Production: https://snewroof-portal.vercel.app
Dashboard: https://vercel.com/dashboard
```

**Next Steps:**
1. Monitor Vercel dashboard for deployments
2. Check application logs regularly
3. Set up error tracking (optional)
4. Configure custom domain (optional)
5. Set up analytics (optional)

---

**Vercel CLI Commands:**
```bash
vercel login                    # Login to Vercel
vercel ls                       # List projects
vercel logs                     # View logs
vercel env ls                  # List environment variables
vercel deploy                   # Deploy to preview
vercel --prod                   # Deploy to production
```

---

**Status**: ✅ Vercel Ready  
**Version**: 1.0.0  
**Last Updated**: 2026
