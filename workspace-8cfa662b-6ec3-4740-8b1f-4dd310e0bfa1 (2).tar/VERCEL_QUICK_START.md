# 🚀 Quick Start - Vercel Deployment

Deploy Snewroof Operations Portal to Vercel in 5 steps!

---

## ⏱️ Time Estimate

| Step | Time |
|------|-------|
| 1. Create Vercel Postgres | 2 min |
| 2. Push to GitHub | 2 min |
| 3. Deploy to Vercel | 3 min |
| 4. Configure Environment | 5 min |
| 5. Seed Database | 2 min |
| **Total** | **~14 minutes** |

---

## 🎯 Step 1: Create Database (2 minutes)

### Option A: Vercel Postgres (Recommended)

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Login to Vercel
vercel login

# 3. Create database
vercel postgres create

# 4. Name your database (e.g., snewroof-db)
# 5. Click "Continue" to create
```

### Get Database Connection String

```bash
# Via CLI
vercel postgres ls

# Via Dashboard
# 1. Go to: https://vercel.com/dashboard
# 2. Select your project > Storage > Vercel Postgres
# 3. Click on your database
# 4. Copy DATABASE_URL

# Example:
# postgresql://default:xxxxx@ep-xyz.aws.us-east-1.aws.com:5432/vercel-db?sslmode=require
```

---

## 🎯 Step 2: Update Schema for PostgreSQL (1 minute)

```bash
# Use PostgreSQL schema for production
cp prisma/schema.postgresql.prisma prisma/schema.prisma

# Generate Prisma client
bun run db:generate
```

---

## 🎯 Step 3: Push to GitHub (2 minutes)

```bash
# Initialize git (if not already)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - Ready for Vercel"

# Create repository on GitHub and push
# 1. Go to: https://github.com/new
# 2. Repository name: snewroof-portal
# 3. Click "Create repository"
# 4. Follow instructions to push

# Or if repo exists:
git remote add origin https://github.com/your-username/snewroof-portal.git
git push -u origin main
```

---

## 🎯 Step 4: Deploy to Vercel (3 minutes)

### Option A: GitHub Integration (Easiest)

```bash
# 1. Go to: https://vercel.com/new
# 2. Click "Import Git Repository"
# 3. Select: snewroof-portal
# 4. Framework: Next.js (auto-detected)
# 5. Root Directory: . (or leave empty)
# 6. Click "Deploy"

# Wait 1-2 minutes for deployment
```

### Option B: CLI Deployment

```bash
# From project root
vercel --prod

# Follow prompts:
# - Link to existing project? Y
# - Select project
# - Deploy to production
```

### Your Application URL

```
Production: https://snewroof-portal.vercel.app
Preview: https://snewroof-portal-git-branch.vercel.app
```

---

## 🎯 Step 5: Configure Environment Variables (5 minutes)

### Add Required Variables

Go to: https://vercel.com/dashboard > Your Project > Settings > Environment Variables

Add these three required variables:

#### 1. DATABASE_URL
```
Name: DATABASE_URL
Value: [paste your Vercel Postgres connection string]
Environments: ✅ Production ✅ Preview ✅ Development
```

#### 2. NEXTAUTH_URL
```
Name: NEXTAUTH_URL
Value: https://snewroof-portal.vercel.app
Environments: ✅ Production ✅ Preview
```

⚠️ IMPORTANT: Must be HTTPS and match your Vercel domain exactly!

#### 3. NEXTAUTH_SECRET
```
Name: NEXTAUTH_SECRET
Value: [paste your generated secret]

Generate one:
openssl rand -base64 32

Or:
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

Environments: ✅ Production ✅ Preview ✅ Development
```

⚠️ CRITICAL: Must be 32+ random characters!

### Optional Variables (if needed)

```
SMTP_HOST
SMTP_PORT
SMTP_USER
SMTP_PASSWORD
SMTP_FROM
GHL_API_KEY
GHL_LOCATION_ID
NEXT_PUBLIC_SENTRY_DSN
NEXT_PUBLIC_GA_ID
```

### Re-deploy After Adding Variables

```bash
# Vercel CLI
vercel --prod --force

# Or push a small change to trigger redeploy
git commit --allow-empty -m "Add environment variables"
git push
```

---

## 🎯 Step 6: Seed Database (2 minutes)

### Create Seed Script

```bash
# Create Vercel-specific seed script
cat > scripts/vercel-seed.mjs << 'EOF'
import { db } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function seed() {
  console.log("🌱 Seeding database...");

  // Clear existing data
  await prisma.activityLog.deleteMany();
  await prisma.alert.deleteMany();
  await prisma.report.deleteMany();
  await prisma.lead.deleteMany();
  await prisma.websiteCheck.deleteMany();
  await prisma.backupLog.deleteMany();
  await prisma.website.deleteMany();
  await prisma.task.deleteMany();
  await prisma.project.deleteMany();
  await prisma.cost.deleteMany();
  await prisma.apiKey.deleteMany();
  await prisma.tool.deleteMany();
  await prisma.user.deleteMany();

  // Hash passwords
  const adminPassword = await bcrypt.hash("admin123", 10);
  const managerPassword = await bcrypt.hash("manager123", 10);
  const analystPassword = await bcrypt.hash("analyst123", 10);

  // Create users
  const admin = await prisma.user.create({
    data: {
      email: "admin@snewroof.com",
      name: "Topon Mohonto",
      password: adminPassword,
      role: "admin",
      isActive: true
    }
  });

  const manager = await prisma.user.create({
    data: {
      email: "manager@snewroof.com",
      name: "John Manager",
      password: managerPassword,
      role: "manager",
      isActive: true
    }
  });

  const analyst = await prisma.user.create({
    data: {
      email: "analyst@snewroof.com",
      name: "Jane Analyst",
      password: analystPassword,
      role: "analyst",
      isActive: true
    }
  });

  console.log("✅ Created users");

  // Create tools, costs, projects, tasks, websites, alerts, leads, activity logs
  // (Same as existing seed.mjs but using PostgreSQL)

  console.log("\n🎉 Database seeded successfully!");
  console.log("\n📝 Login Credentials:");
  console.log("   Admin:    admin@snewroof.com / admin123");
  console.log("   Manager:  manager@snewroof.com / manager123");
  console.log("   Analyst:  analyst@snewroof.com / analyst123");
}

seed().catch(console.error);
EOF
```

### Push Schema to Database

```bash
# Run database push
vercel env pull .env.local
bun run db:push

# Or use DATABASE_URL directly
DATABASE_URL="your-vercel-postgres-url" bun run db:push
```

---

## ✅ Verification

### Check Application Health

```bash
# Health check
curl https://snewroof-portal.vercel.app/api/health

# Should return:
{
  "status": "healthy",
  "timestamp": "...",
  "services": {
    "database": "healthy",
    "api": "healthy"
  }
}
```

### Access Your Portal

```
Production URL: https://snewroof-portal.vercel.app/login

Default Login:
Admin:    admin@snewroof.com / admin123
Manager:  manager@snewroof.com / manager123
Analyst:  analyst@snewroof.com / analyst123
```

---

## 🔧 Common Issues & Solutions

### Issue: Build Fails

**Solution:**
```bash
# Clear Vercel cache
vercel build --force

# Check package.json
cat package.json | grep buildCommand
```

### Issue: Database Connection Error

**Solution:**
1. Verify DATABASE_URL in Vercel dashboard
2. Check Vercel Postgres is running
3. Test connection locally first
4. Check Vercel logs for errors

### Issue: Environment Variables Not Working

**Solution:**
```bash
# Pull environment locally
vercel env pull

# Verify all variables are set
cat .env.local

# Push back to Vercel
vercel env push .env.local
```

### Issue: NEXTAUTH_SECRET Error

**Solution:**
```bash
# Generate new secret
openssl rand -base64 32

# Update in Vercel dashboard
# Project > Settings > Environment Variables
# Add/Update NEXTAUTH_SECRET

# Re-deploy
vercel --prod --force
```

---

## 📊 Vercel Dashboard Features

### Monitor Your Deployment

Go to: https://vercel.com/dashboard

**Features:**
- 📈 Real-time analytics
- 📊 Deployment history
- 🐛 Error logs
- ⚡ Function logs
- 🔄 Rollback capability
- 👁 Environment variable management
- 🔗 Domain configuration

### View Logs

```bash
# Via CLI
vercel logs

# Via Dashboard
# Dashboard > Your Project > Logs
```

### Check Analytics

```bash
# Via CLI
vercel ls

# Via Dashboard
# Dashboard > Analytics
```

---

## 🎉 Success Checklist

- [ ] ✅ Vercel Postgres database created
- [ ] ✅ DATABASE_URL copied and added to Vercel
- [ ] ✅ Schema updated for PostgreSQL
- [ ] ✅ Schema pushed to database
- [ ] ✅ Repository pushed to GitHub
- [ ] ✅ Project deployed to Vercel
- [ ] ✅ NEXTAUTH_URL set to Vercel domain
- [ ] ✅ NEXTAUTH_SECRET generated (32+ chars)
- [ ] ✅ Environment variables configured
- [ ] ✅ Database seeded with test data
- [ ] ✅ Health check passing
- [ ] Application accessible at URL
- [ ] Login working
- [ ] All features tested

---

## 📞 Support & Resources

### Documentation

- **Vercel Docs**: https://vercel.com/docs
- **Next.js on Vercel**: https://vercel.com/docs/frameworks/nextjs
- **Vercel Postgres**: https://vercel.com/docs/storage/vercel-postgres
- **Full Guide**: See `VERCEL_DEPLOYMENT.md`

### Vercel CLI Commands

```bash
vercel login                    # Login
vercel ls                       # List projects
vercel logs                     # View logs
vercel env ls                  # List env vars
vercel env pull                 # Pull env vars
vercel deploy                   # Deploy to preview
vercel --prod                   # Deploy to production
vercel build --force           # Force rebuild
```

---

## 🚀 You're Live!

**Your Snewroof Operations Portal is deployed:**
```
🎉 https://snewroof-portal.vercel.app
```

**Next Steps:**
1. ⚠️ Change default passwords immediately
2. 📊 Monitor Vercel dashboard for deployments
3. 📈 Set up analytics (optional)
4. 📝 Configure custom domain (optional)
5. 🔄 Set up continuous deployment from GitHub

**Remember:**
- Use HTTPS for all URLs
- Keep NEXTAUTH_SECRET secure
- Monitor logs regularly
- Update dependencies regularly
- Test changes in preview before production

---

**Version**: 1.0.0  
**Status**: ✅ Vercel Ready  
**Last Updated**: 2026

Good luck! 🚀
