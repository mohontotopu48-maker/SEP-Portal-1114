import { serve } from '@hono/node-server'
import { Hono } from 'hono'

const app = new Hono()
const PORT = 3001

// Store for tracking website statuses
interface WebsiteCheck {
  status: 'up' | 'down'
  responseTime: number
  timestamp: Date
}

const checks = new Map<string, WebsiteCheck[]>()

async function checkWebsite(url: string): Promise<{ status: 'up' | 'down'; responseTime: number; error?: string }> {
  const start = Date.now()

  try {
    const response = await fetch(url, {
      method: 'HEAD',
      signal: AbortSignal.timeout(10000) // 10 second timeout
    })

    const responseTime = Date.now() - start

    if (response.ok) {
      return { status: 'up', responseTime }
    } else {
      return { status: 'down', responseTime, error: `HTTP ${response.status}` }
    }
  } catch (error: any) {
    const responseTime = Date.now() - start
    return {
      status: 'down',
      responseTime,
      error: error.message || 'Connection failed'
    }
  }
}

app.get('/health', (c) => {
  return c.json({ status: 'ok', port: PORT })
})

app.post('/check', async (c) => {
  const { url } = await c.req.json()

  if (!url) {
    return c.json({ error: 'URL is required' }, 400)
  }

  const result = await checkWebsite(url)

  // Store check result
  if (!checks.has(url)) {
    checks.set(url, [])
  }

  const urlChecks = checks.get(url)!
  urlChecks.push({
    status: result.status,
    responseTime: result.responseTime,
    timestamp: new Date()
  })

  // Keep only last 100 checks
  if (urlChecks.length > 100) {
    urlChecks.shift()
  }

  return c.json(result)
})

app.get('/status/:url(*)', (c) => {
  const url = decodeURIComponent(c.req.param('url'))
  const urlChecks = checks.get(url)

  if (!urlChecks || urlChecks.length === 0) {
    return c.json({ status: 'unknown', message: 'No checks performed yet' })
  }

  const latestCheck = urlChecks[urlChecks.length - 1]
  const upChecks = urlChecks.filter(c => c.status === 'up').length
  const uptime = (upChecks / urlChecks.length) * 100

  return c.json({
    status: latestCheck.status,
    responseTime: latestCheck.responseTime,
    uptime: Math.round(uptime * 100) / 100,
    totalChecks: urlChecks.length,
    lastChecked: latestCheck.timestamp
  })
})

app.get('/history/:url(*)', (c) => {
  const url = decodeURIComponent(c.req.param('url'))
  const urlChecks = checks.get(url)

  if (!urlChecks || urlChecks.length === 0) {
    return c.json([])
  }

  return c.json(urlChecks)
})

console.log(`Website Monitor Service running on port ${PORT}`)

serve({
  fetch: app.fetch,
  port: PORT
})
