#!/bin/bash
set -e

echo "🏗️  Building Snewroof Operations Portal..."

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}Step 1: Installing dependencies...${NC}"
bun install

echo -e "${BLUE}Step 2: Generating Prisma client...${NC}"
bun run db:generate

echo -e "${BLUE}Step 3: Running database migrations...${NC}"
bun run db:push

echo -e "${BLUE}Step 4: Building Next.js application...${NC}"
bun run build

echo -e "${GREEN}✅ Build completed successfully!${NC}"
echo ""
echo "To start the production server:"
echo "  bun start"
echo ""
echo "To run with Docker:"
echo "  docker-compose up -d"
