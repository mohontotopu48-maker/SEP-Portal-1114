#!/bin/bash
# Quick environment variable generator
# Usage: bun scripts/generate-secret.sh

echo "🔑 Generating NEXTAUTH_SECRET..."

# Method 1: OpenSSL
if command -v openssl &> /dev/null; then
    SECRET=$(openssl rand -base64 32)
    echo ""
    echo "✅ Generated with OpenSSL:"
    echo "$SECRET"
    echo ""
    echo "Add to .env:"
    echo "NEXTAUTH_SECRET=\"$SECRET\""
    exit 0
fi

# Method 2: Node.js
if command -v node &> /dev/null; then
    SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('base64'))")
    echo ""
    echo "✅ Generated with Node.js:"
    echo "$SECRET"
    echo ""
    echo "Add to .env:"
    echo "NEXTAUTH_SECRET=\"$SECRET\""
    exit 0
fi

# Method 3: Bun
if command -v bun &> /dev/null; then
    SECRET=$(bun -e "console.log(crypto.randomBytes(32).toString('base64'))")
    echo ""
    echo "✅ Generated with Bun:"
    echo "$SECRET"
    echo ""
    echo "Add to .env:"
    echo "NEXTAUTH_SECRET=\"$SECRET\""
    exit 0
fi

echo "❌ Error: No suitable crypto tool found (openssl, node, or bun)"
exit 1
