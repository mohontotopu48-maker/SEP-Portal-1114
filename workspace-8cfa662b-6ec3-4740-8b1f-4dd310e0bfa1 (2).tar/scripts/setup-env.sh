#!/bin/bash
# =====================================================================
# SNEWROOF ENVIRONMENT SETUP SCRIPT
# =====================================================================
# This script helps you generate and configure environment variables
# =====================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  SNEWROOF ENVIRONMENT SETUP                          ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# =====================================================================
# Check for existing .env file
# =====================================================================
if [ -f .env ]; then
    echo -e "${YELLOW}⚠️  Warning: .env file already exists${NC}"
    read -p "Do you want to backup and overwrite it? (y/n): " backup_choice
    if [[ $backup_choice != "y" ]]; then
        echo -e "${YELLOW}Exiting without changes.${NC}"
        exit 0
    fi
    cp .env .env.backup.$(date +%Y%m%d_%H%M%S)
    echo -e "${GREEN}✅ Backup created: .env.backup.$(date +%Y%m%d_%H%M%S)${NC}"
fi

# =====================================================================
# Generate NEXTAUTH_SECRET
# =====================================================================
echo -e "\n${BLUE}🔑 Generating secure NEXTAUTH_SECRET...${NC}"
SECRET=$(openssl rand -base64 32 2>/dev/null || node -e "console.log(require('crypto').randomBytes(32).toString('base64'))" 2>/dev/null || echo "your-secret-key-change-in-production-32-characters-minimum")

echo -e "${GREEN}✅ Generated NEXTAUTH_SECRET${NC}"
echo "   $SECRET"
echo ""

# =====================================================================
# Interactive Configuration
# =====================================================================
echo -e "${BLUE}📝 Configuration${NC}"
echo ""

# Database URL
echo -e "${YELLOW}Database Configuration${NC}"
echo "1) SQLite (file-based, simple)"
echo "2) PostgreSQL (recommended for production)"
read -p "Choose database type (1-2) [1]: " db_choice

case $db_choice in
    2)
        read -p "PostgreSQL connection string (postgresql://user:pass@host:5432/db): " db_url
        DATABASE_URL="$db_url"
        ;;
    *)
        DATABASE_URL="file:./db/custom.db"
        echo -e "${GREEN}✅ Using SQLite (file-based)${NC}"
        ;;
esac

# Domain/URL
echo ""
echo -e "${YELLOW}NextAuth Configuration${NC}"
read -p "Production domain (e.g., snewroof.com or leave blank for localhost): " domain

if [ -z "$domain" ]; then
    NEXTAUTH_URL="http://localhost:3000"
    echo -e "${GREEN}✅ Using localhost: http://localhost:3000${NC}"
else
    # Check if domain includes protocol
    if [[ $domain != https://* ]] && [[ $domain != http://* ]]; then
        NEXTAUTH_URL="https://$domain"
    else
        NEXTAUTH_URL="$domain"
    fi
    echo -e "${GREEN}✅ Using domain: $NEXTAUTH_URL${NC}"
fi

# Node Environment
echo ""
read -p "Environment (development/production) [development]: " node_env
NODE_ENV="${node_env:-development}"

# Optional: SMTP/Email
echo ""
echo -e "${YELLOW}Email Configuration (Optional)${NC}"
read -p "Configure SMTP for email notifications? (y/n) [n]: " smtp_choice

SMTP_HOST=""
SMTP_PORT=""
SMTP_USER=""
SMTP_PASSWORD=""
SMTP_FROM=""

if [[ $smtp_choice == "y" ]]; then
    read -p "SMTP Host (e.g., smtp.gmail.com): " smtp_host
    read -p "SMTP Port (e.g., 587): " smtp_port
    read -p "SMTP User (email address): " smtp_user
    read -s -p "SMTP Password: " smtp_password
    read -p "From Email (e.g., noreply@snewroof.com): " smtp_from
    
    SMTP_HOST="$smtp_host"
    SMTP_PORT="$smtp_port"
    SMTP_USER="$smtp_user"
    SMTP_PASSWORD="$smtp_password"
    SMTP_FROM="$smtp_from"
fi

# Optional: GHL
echo ""
echo -e "${YELLOW}GoHighLevel CRM Configuration (Optional)${NC}"
read -p "Configure GHL integration? (y/n) [n]: " ghl_choice

GHL_API_KEY=""
GHL_LOCATION_ID=""

if [[ $ghl_choice == "y" ]]; then
    read -p "GHL API Key: " ghl_key
    read -p "GHL Location ID: " ghl_location
    
    GHL_API_KEY="$ghl_key"
    GHL_LOCATION_ID="$ghl_location"
fi

# =====================================================================
# Create .env file
# =====================================================================
echo ""
echo -e "${BLUE}📝 Creating .env file...${NC}"

cat > .env << EOF
# =====================================================================
# SNEWROOF OPERATIONS PORTAL - ENVIRONMENT VARIABLES
# Generated: $(date)
# =====================================================================

# Database
DATABASE_URL="$DATABASE_URL"

# NextAuth
NEXTAUTH_URL="$NEXTAUTH_URL"
NEXTAUTH_SECRET="$SECRET"

# Application
NODE_ENV="$NODE_ENV"
PORT="3000"

# Email/SMTP (Optional)
EOF

if [[ $smtp_choice == "y" ]]; then
    cat >> .env << EOF

SMTP_HOST="$SMTP_HOST"
SMTP_PORT="$SMTP_PORT"
SMTP_USER="$SMTP_USER"
SMTP_PASSWORD="$SMTP_PASSWORD"
SMTP_FROM="$SMTP_FROM"
EOF
fi

if [[ $ghl_choice == "y" ]]; then
    cat >> .env << EOF

# GoHighLevel
GHL_API_KEY="$GHL_API_KEY"
GHL_LOCATION_ID="$GHL_LOCATION_ID"
EOF
fi

cat >> .env << EOF

# Website Monitor
WEBSITE_MONITOR_PORT="3001"

# Logging
LOG_LEVEL="info"
EOF

# Secure the file
chmod 600 .env

echo -e "${GREEN}✅ .env file created successfully!${NC}"

# =====================================================================
# Summary
# =====================================================================
echo ""
echo -e "${BLUE}════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                    SUMMARY                              ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${GREEN}✅ Configuration Complete!${NC}"
echo ""
echo -e "Database:           ${YELLOW}$DATABASE_URL${NC}"
echo -e "NextAuth URL:       ${YELLOW}$NEXTAUTH_URL${NC}"
echo -e "Environment:         ${YELLOW}$NODE_ENV${NC}"
echo -e "NEXTAUTH_SECRET:   ${GREEN}✓ Generated (32+ chars)${NC}"
if [[ $smtp_choice == "y" ]]; then
    echo -e "Email/SMTP:        ${GREEN}✓ Configured${NC}"
fi
if [[ $ghl_choice == "y" ]]; then
    echo -e "GHL Integration:    ${GREEN}✓ Configured${NC}"
fi
echo ""
echo -e "${BLUE}📝 Next Steps:${NC}"
echo ""
echo "1. Review .env file to confirm all values"
echo "2. For production, update NEXTAUTH_URL with HTTPS"
echo "3. For production, change default passwords in database"
echo "4. Run: bun seed.mjs (if database needs seeding)"
echo "5. Start application:"
echo "   - Development: bun run dev"
echo "   - Production: docker-compose up -d"
echo ""
echo -e "${YELLOW}⚠️  Security Reminders:${NC}"
echo "   • Never commit .env to version control"
echo "   • Use strong, unique passwords"
echo "   • Keep NEXTAUTH_SECRET secret"
echo "   • Use HTTPS in production"
echo "   • Set up regular backups"
echo ""
echo -e "${GREEN}🎉 Setup complete!${NC}"
