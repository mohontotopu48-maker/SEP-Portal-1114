import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const cost = await db.cost.findUnique({
      where: { id: params.id },
      include: {
        tool: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    if (!cost) {
      return NextResponse.json(
        { error: 'Cost not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(cost)
  } catch (error) {
    console.error('Error fetching cost:', error)
    return NextResponse.json(
      { error: 'Failed to fetch cost' },
      { status: 500 }
    )
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const {
      name,
      description,
      category,
      amount,
      currency,
      billingCycle,
      dueDate,
      renewalDate,
      isRecurring,
      toolId,
      vendor,
      status
    } = body

    const cost = await db.cost.update({
      where: { id: params.id },
      data: {
        ...(name !== undefined && { name }),
        ...(description !== undefined && { description }),
        ...(category !== undefined && { category }),
        ...(amount !== undefined && { amount: parseFloat(amount) }),
        ...(currency !== undefined && { currency }),
        ...(billingCycle !== undefined && { billingCycle }),
        ...(dueDate !== undefined && { dueDate: dueDate ? new Date(dueDate) : null }),
        ...(renewalDate !== undefined && { renewalDate: renewalDate ? new Date(renewalDate) : null }),
        ...(isRecurring !== undefined && { isRecurring }),
        ...(toolId !== undefined && { toolId: toolId || null }),
        ...(vendor !== undefined && { vendor }),
        ...(status !== undefined && { status })
      },
      include: {
        tool: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    return NextResponse.json(cost)
  } catch (error) {
    console.error('Error updating cost:', error)
    return NextResponse.json(
      { error: 'Failed to update cost' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    await db.cost.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting cost:', error)
    return NextResponse.json(
      { error: 'Failed to delete cost' },
      { status: 500 }
    )
  }
}
