import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Calculate total monthly costs
    const costs = await db.cost.findMany({
      where: {
        status: 'active',
        category: {
          in: ['monthly', 'subscription', 'license']
        }
      }
    })

    const totalMonthlyCosts = costs.reduce((sum, cost) => {
      if (cost.billingCycle === 'yearly') {
        return sum + (cost.amount / 12)
      } else {
        return sum + cost.amount
      }
    }, 0)

    // Count active tools
    const activeTools = await db.tool.count({
      where: {
        status: 'active'
      }
    })

    // Count website statuses
    const websitesUp = await db.website.count({
      where: {
        status: 'up',
        isActive: true
      }
    })

    const websitesDown = await db.website.count({
      where: {
        status: 'down',
        isActive: true
      }
    })

    // Count task statuses
    const openTasks = await db.task.count({
      where: {
        status: {
          in: ['todo', 'in_progress', 'review']
        }
      }
    })

    const overdueTasks = await db.task.count({
      where: {
        status: {
          in: ['todo', 'in_progress', 'review']
        },
        dueDate: {
          lt: new Date()
        }
      }
    })

    const completedTasks = await db.task.count({
      where: {
        status: 'done'
      }
    })

    // Count new leads (created in last 30 days)
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    const newLeads = await db.lead.count({
      where: {
        createdAt: {
          gte: thirtyDaysAgo
        }
      }
    })

    return NextResponse.json({
      totalMonthlyCosts: Math.round(totalMonthlyCosts * 100) / 100,
      activeTools,
      websitesUp,
      websitesDown,
      openTasks,
      overdueTasks,
      completedTasks,
      newLeads
    })
  } catch (error) {
    console.error('Error fetching dashboard stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch dashboard stats' },
      { status: 500 }
    )
  }
}
