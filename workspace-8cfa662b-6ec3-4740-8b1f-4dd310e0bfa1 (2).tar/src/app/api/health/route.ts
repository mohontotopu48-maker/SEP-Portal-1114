import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const healthCheck = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    version: '1.0.0',
    services: {
      database: 'unknown',
      api: 'healthy'
    }
  }

  // Check database connection
  try {
    await db.$queryRaw`SELECT 1`
    healthCheck.services.database = 'healthy'
  } catch (error) {
    healthCheck.services.database = 'unhealthy'
    healthCheck.status = 'degraded'
  }

  const statusCode = healthCheck.status === 'healthy' ? 200 : 503
  return NextResponse.json(healthCheck, { status: statusCode })
}
