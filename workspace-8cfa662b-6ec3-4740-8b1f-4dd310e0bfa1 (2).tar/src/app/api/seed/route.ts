import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export async function POST() {
  try {
    // Clear existing data
    await db.activityLog.deleteMany()
    await db.alert.deleteMany()
    await db.report.deleteMany()
    await db.lead.deleteMany()
    await db.websiteCheck.deleteMany()
    await db.backupLog.deleteMany()
    await db.website.deleteMany()
    await db.task.deleteMany()
    await db.project.deleteMany()
    await db.cost.deleteMany()
    await db.apiKey.deleteMany()
    await db.tool.deleteMany()
    await db.user.deleteMany()

    // Hash default passwords
    const adminPassword = await bcrypt.hash('admin123', 10)
    const managerPassword = await bcrypt.hash('manager123', 10)
    const analystPassword = await bcrypt.hash('analyst123', 10)

    // Create users
    const admin = await db.user.create({
      data: {
        email: 'admin@snewroof.com',
        name: 'Topon Mohonto',
        password: adminPassword,
        role: 'admin',
        isActive: true
      }
    })

    const manager = await db.user.create({
      data: {
        email: 'manager@snewroof.com',
        name: 'John Manager',
        password: managerPassword,
        role: 'manager',
        isActive: true
      }
    })

    const analyst = await db.user.create({
      data: {
        email: 'analyst@snewroof.com',
        name: 'Jane Analyst',
        password: analystPassword,
        role: 'analyst',
        isActive: true
      }
    })

    // Create tools
    const tool1 = await db.tool.create({
      data: {
        name: 'AWS',
        description: 'Cloud infrastructure services',
        category: 'subscription',
        costMonthly: 450.00,
        currency: 'USD',
        status: 'active',
        ownerUserId: admin.id
      }
    })

    const tool2 = await db.tool.create({
      data: {
        name: 'Google Analytics',
        description: 'Website analytics',
        category: 'api',
        costMonthly: 0.00,
        currency: 'USD',
        status: 'active',
        ownerUserId: manager.id
      }
    })

    const tool3 = await db.tool.create({
      data: {
        name: 'Slack',
        description: 'Team communication',
        category: 'subscription',
        costMonthly: 12.50,
        currency: 'USD',
        status: 'active',
        ownerUserId: admin.id
      }
    })

    const tool4 = await db.tool.create({
      data: {
        name: 'GitHub Enterprise',
        description: 'Code repository & collaboration',
        category: 'subscription',
        costMonthly: 21.00,
        currency: 'USD',
        status: 'active',
        ownerUserId: admin.id
      }
    })

    // Create costs
    await db.cost.create({
      data: {
        name: 'AWS Infrastructure',
        description: 'Monthly AWS hosting costs',
        category: 'monthly',
        amount: 450.00,
        currency: 'USD',
        billingCycle: 'monthly',
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        status: 'active',
        isRecurring: true,
        toolId: tool1.id,
        vendor: 'Amazon Web Services'
      }
    })

    await db.cost.create({
      data: {
        name: 'Slack Business Plan',
        description: 'Team collaboration tool',
        category: 'subscription',
        amount: 12.50,
        currency: 'USD',
        billingCycle: 'monthly',
        dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
        status: 'active',
        isRecurring: true,
        toolId: tool3.id,
        vendor: 'Salesforce'
      }
    })

    await db.cost.create({
      data: {
        name: 'SSL Certificate Renewal',
        description: 'Annual SSL certificate for main site',
        category: 'license',
        amount: 199.00,
        currency: 'USD',
        billingCycle: 'yearly',
        dueDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
        status: 'active',
        isRecurring: true,
        vendor: 'DigiCert'
      }
    })

    // Create projects
    const project1 = await db.project.create({
      data: {
        name: 'Website Redesign',
        description: 'Complete overhaul of main company website',
        status: 'active',
        priority: 'high',
        startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        progress: 65
      }
    })

    const project2 = await db.project.create({
      data: {
        name: 'CRM Integration',
        description: 'Integrate GHL with internal systems',
        status: 'active',
        priority: 'medium',
        startDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
        dueDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000),
        progress: 30
      }
    })

    // Create tasks
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000)
    const today = new Date()
    const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000)
    const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)

    await db.task.createMany({
      data: [
        {
          title: 'Design new homepage',
          description: 'Create wireframes and mockups for the new homepage design',
          status: 'in_progress',
          priority: 'high',
          dueDate: tomorrow,
          assigneeId: analyst.id,
          creatorId: manager.id,
          projectId: project1.id
        },
        {
          title: 'Implement API endpoints for CRM sync',
          description: 'Build REST API endpoints for GHL integration',
          status: 'todo',
          priority: 'high',
          dueDate: nextWeek,
          assigneeId: admin.id,
          creatorId: manager.id,
          projectId: project2.id
        },
        {
          title: 'Set up monitoring dashboard',
          description: 'Configure real-time monitoring for all production servers',
          status: 'todo',
          priority: 'medium',
          dueDate: nextWeek,
          assigneeId: admin.id,
          creatorId: admin.id
        },
        {
          title: 'Fix SSL certificate on staging',
          description: 'SSL certificate expired on staging environment',
          status: 'done',
          priority: 'urgent',
          dueDate: yesterday,
          assigneeId: admin.id,
          creatorId: admin.id,
          completedAt: new Date()
        },
        {
          title: 'Update documentation',
          description: 'Update API documentation with new endpoints',
          status: 'review',
          priority: 'low',
          dueDate: tomorrow,
          assigneeId: analyst.id,
          creatorId: manager.id,
          projectId: project2.id
        },
        {
          title: 'Optimize database queries',
          description: 'Review and optimize slow database queries',
          status: 'todo',
          priority: 'medium',
          dueDate: yesterday, // This will be overdue
          assigneeId: admin.id,
          creatorId: manager.id
        }
      ]
    })

    // Create websites
    const website1 = await db.website.create({
      data: {
        name: 'Main Website',
        url: 'https://snewroof.com',
        description: 'Primary company website',
        status: 'up',
        uptime: 99.95,
        sslValid: true,
        sslExpiry: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000),
        lastChecked: new Date(),
        lastUp: new Date(),
        isActive: true,
        checkInterval: 5
      }
    })

    const website2 = await db.website.create({
      data: {
        name: 'Admin Portal',
        url: 'https://admin.snewroof.com',
        description: 'Internal administration portal',
        status: 'up',
        uptime: 99.8,
        sslValid: true,
        sslExpiry: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
        lastChecked: new Date(),
        lastUp: new Date(),
        isActive: true,
        checkInterval: 5
      }
    })

    const website3 = await db.website.create({
      data: {
        name: 'API Server',
        url: 'https://api.snewroof.com',
        description: 'Backend API server',
        status: 'down',
        uptime: 98.5,
        sslValid: true,
        sslExpiry: new Date(Date.now() + 120 * 24 * 60 * 60 * 1000),
        lastChecked: new Date(),
        lastDown: new Date(Date.now() - 30 * 60 * 1000),
        isActive: true,
        checkInterval: 5
      }
    })

    // Create website checks
    for (let i = 0; i < 10; i++) {
      const checkTime = new Date(Date.now() - (10 - i) * 5 * 60 * 1000)
      await db.websiteCheck.create({
        data: {
          websiteId: website1.id,
          status: 'up',
          responseTime: 150 + Math.floor(Math.random() * 50),
          checkedAt: checkTime
        }
      })
    }

    // Create alerts
    await db.alert.createMany({
      data: [
        {
          type: 'website_down',
          severity: 'critical',
          title: 'API Server is down',
          message: 'The API server at https://api.snewroof.com is not responding.',
          isRead: false,
          isResolved: false,
          websiteId: website3.id
        },
        {
          type: 'cost_due',
          severity: 'warning',
          title: 'Slack payment due soon',
          message: 'Slack Business Plan payment of $12.50 is due in 15 days.',
          isRead: true,
          isResolved: false
        },
        {
          type: 'task_overdue',
          severity: 'warning',
          title: 'Task overdue',
          message: 'Task "Optimize database queries" was due yesterday.',
          isRead: true,
          isResolved: false
        },
        {
          type: 'ssl_expiry',
          severity: 'info',
          title: 'SSL certificate expiring soon',
          message: 'SSL certificate for Admin Portal expires in 90 days.',
          isRead: false,
          isResolved: false,
          websiteId: website2.id
        }
      ]
    })

    // Create leads
    await db.lead.createMany({
      data: [
        {
          ghlId: 'ghl_001',
          firstName: 'John',
          lastName: 'Doe',
          email: 'john.doe@example.com',
          phone: '+1-555-0101',
          company: 'Example Corp',
          source: 'ghl',
          status: 'new',
          assignedToId: manager.id
        },
        {
          ghlId: 'ghl_002',
          firstName: 'Jane',
          lastName: 'Smith',
          email: 'jane.smith@example.com',
          phone: '+1-555-0102',
          company: 'Tech Startup',
          source: 'ghl',
          status: 'contacted',
          assignedToId: manager.id
        },
        {
          ghlId: 'ghl_003',
          firstName: 'Bob',
          lastName: 'Johnson',
          email: 'bob.j@example.com',
          phone: '+1-555-0103',
          company: 'Digital Agency',
          source: 'ghl',
          status: 'qualified',
          assignedToId: analyst.id
        },
        {
          firstName: 'Alice',
          lastName: 'Williams',
          email: 'alice.w@example.com',
          phone: '+1-555-0104',
          company: 'Marketing Co',
          source: 'manual',
          status: 'new'
        }
      ]
    })

    // Create activity logs
    await db.activityLog.createMany({
      data: [
        {
          userId: admin.id,
          action: 'login',
          entityType: 'user',
          ipAddress: '192.168.1.1',
          userAgent: 'Mozilla/5.0...'
        },
        {
          userId: manager.id,
          action: 'create',
          entityType: 'task',
          entityId: 'task_1'
        },
        {
          userId: admin.id,
          action: 'update',
          entityType: 'website',
          entityId: website1.id
        }
      ]
    })

    return NextResponse.json({
      success: true,
      message: 'Database seeded successfully'
    })
  } catch (error) {
    console.error('Error seeding database:', error)
    return NextResponse.json(
      { error: 'Failed to seed database', details: String(error) },
      { status: 500 }
    )
  }
}
