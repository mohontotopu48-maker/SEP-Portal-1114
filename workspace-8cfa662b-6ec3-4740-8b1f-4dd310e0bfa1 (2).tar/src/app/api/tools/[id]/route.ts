import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const tool = await db.tool.findUnique({
      where: { id: params.id },
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        apiKeys: {
          orderBy: {
            createdAt: 'desc'
          }
        },
        costs: {
          orderBy: {
            dueDate: 'asc'
          }
        }
      }
    })

    if (!tool) {
      return NextResponse.json(
        { error: 'Tool not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(tool)
  } catch (error) {
    console.error('Error fetching tool:', error)
    return NextResponse.json(
      { error: 'Failed to fetch tool' },
      { status: 500 }
    )
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const {
      name,
      description,
      category,
      apiKey,
      apiEndpoint,
      costMonthly,
      costYearly,
      currency,
      renewalDate,
      expiryDate,
      status,
      usageLimit,
      currentUsage,
      ownerUserId,
      notes
    } = body

    const tool = await db.tool.update({
      where: { id: params.id },
      data: {
        ...(name !== undefined && { name }),
        ...(description !== undefined && { description }),
        ...(category !== undefined && { category }),
        ...(apiKey !== undefined && { apiKey }),
        ...(apiEndpoint !== undefined && { apiEndpoint }),
        ...(costMonthly !== undefined && { costMonthly: costMonthly ? parseFloat(costMonthly) : null }),
        ...(costYearly !== undefined && { costYearly: costYearly ? parseFloat(costYearly) : null }),
        ...(currency !== undefined && { currency }),
        ...(renewalDate !== undefined && { renewalDate: renewalDate ? new Date(renewalDate) : null }),
        ...(expiryDate !== undefined && { expiryDate: expiryDate ? new Date(expiryDate) : null }),
        ...(status !== undefined && { status }),
        ...(usageLimit !== undefined && { usageLimit: usageLimit ? parseInt(usageLimit) : null }),
        ...(currentUsage !== undefined && { currentUsage: currentUsage ? parseInt(currentUsage) : null }),
        ...(ownerUserId !== undefined && { ownerUserId: ownerUserId || null }),
        ...(notes !== undefined && { notes })
      },
      include: {
        owner: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        apiKeys: true
      }
    })

    return NextResponse.json(tool)
  } catch (error) {
    console.error('Error updating tool:', error)
    return NextResponse.json(
      { error: 'Failed to update tool' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    await db.tool.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting tool:', error)
    return NextResponse.json(
      { error: 'Failed to delete tool' },
      { status: 500 }
    )
  }
}
