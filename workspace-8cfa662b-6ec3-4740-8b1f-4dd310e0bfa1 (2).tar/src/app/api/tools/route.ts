import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const detailed = searchParams.get('detailed') === 'true'

    const tools = await db.tool.findMany({
      orderBy: {
        name: 'asc'
      },
      include: detailed ? {
        owner: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      } : undefined,
      select: !detailed ? {
        id: true,
        name: true,
        category: true,
        status: true
      } : undefined
    })

    return NextResponse.json(tools)
  } catch (error) {
    console.error('Error fetching tools:', error)
    return NextResponse.json(
      { error: 'Failed to fetch tools' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      name,
      description,
      category,
      apiKey,
      apiEndpoint,
      costMonthly,
      costYearly,
      currency,
      renewalDate,
      expiryDate,
      status,
      usageLimit,
      currentUsage,
      ownerUserId,
      notes
    } = body

    const tool = await db.tool.create({
      data: {
        name,
        description,
        category,
        apiKey,
        apiEndpoint,
        costMonthly: costMonthly ? parseFloat(costMonthly) : null,
        costYearly: costYearly ? parseFloat(costYearly) : null,
        currency,
        renewalDate: renewalDate ? new Date(renewalDate) : null,
        expiryDate: expiryDate ? new Date(expiryDate) : null,
        status,
        usageLimit,
        currentUsage,
        ownerUserId,
        notes
      }
    })

    return NextResponse.json(tool, { status: 201 })
  } catch (error) {
    console.error('Error creating tool:', error)
    return NextResponse.json(
      { error: 'Failed to create tool' },
      { status: 500 }
    )
  }
}
