import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const website = await db.website.findUnique({
      where: { id: params.id }
    })

    if (!website) {
      return NextResponse.json(
        { error: 'Website not found' },
        { status: 404 }
      )
    }

    // Call website monitor service
    const monitorResponse = await fetch('http://localhost:3001/check', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url: website.url })
    })

    let checkResult
    if (monitorResponse.ok) {
      checkResult = await monitorResponse.json()
    } else {
      checkResult = { status: 'down', responseTime: 0, error: 'Monitor service unavailable' }
    }

    // Update website status
    const previousStatus = website.status
    const newStatus = checkResult.status

    const updatedWebsite = await db.website.update({
      where: { id: params.id },
      data: {
        status: newStatus,
        lastChecked: new Date(),
        ...(newStatus === 'up' ? { lastUp: new Date() } : { lastDown: new Date() })
      }
    })

    // Create check log
    await db.websiteCheck.create({
      data: {
        websiteId: website.id,
        status: newStatus,
        responseTime: checkResult.responseTime,
        errorMessage: checkResult.error
      }
    })

    // Create alert if status changed to down
    if (previousStatus !== 'down' && newStatus === 'down') {
      await db.alert.create({
        data: {
          type: 'website_down',
          severity: 'critical',
          title: `${website.name} is down`,
          message: checkResult.error || 'Website is not responding',
          isRead: false,
          isResolved: false,
          websiteId: website.id
        }
      })
    }

    return NextResponse.json({
      success: true,
      status: newStatus,
      responseTime: checkResult.responseTime,
      website: updatedWebsite
    })
  } catch (error) {
    console.error('Error checking website:', error)
    return NextResponse.json(
      { error: 'Failed to check website' },
      { status: 500 }
    )
  }
}
