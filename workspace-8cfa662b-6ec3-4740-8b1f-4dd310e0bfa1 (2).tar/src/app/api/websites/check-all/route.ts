import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST() {
  try {
    const websites = await db.website.findMany({
      where: {
        isActive: true
      }
    })

    const results = await Promise.allSettled(
      websites.map(async (website) => {
        // Call website monitor service
        const monitorResponse = await fetch('http://localhost:3001/check', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ url: website.url })
        })

        let checkResult
        if (monitorResponse.ok) {
          checkResult = await monitorResponse.json()
        } else {
          checkResult = { status: 'down', responseTime: 0, error: 'Monitor service unavailable' }
        }

        // Update website status
        const previousStatus = website.status
        const newStatus = checkResult.status

        const updatedWebsite = await db.website.update({
          where: { id: website.id },
          data: {
            status: newStatus,
            lastChecked: new Date(),
            ...(newStatus === 'up' ? { lastUp: new Date() } : { lastDown: new Date() })
          }
        })

        // Create check log
        await db.websiteCheck.create({
          data: {
            websiteId: website.id,
            status: newStatus,
            responseTime: checkResult.responseTime,
            errorMessage: checkResult.error
          }
        })

        // Create alert if status changed to down
        if (previousStatus !== 'down' && newStatus === 'down') {
          await db.alert.create({
            data: {
              type: 'website_down',
              severity: 'critical',
              title: `${website.name} is down`,
              message: checkResult.error || 'Website is not responding',
              isRead: false,
              isResolved: false,
              websiteId: website.id
            }
          })
        }

        return updatedWebsite
      })
    )

    const successful = results.filter(r => r.status === 'fulfilled').length
    const failed = results.filter(r => r.status === 'rejected').length

    return NextResponse.json({
      success: true,
      checked: websites.length,
      successful,
      failed
    })
  } catch (error) {
    console.error('Error checking all websites:', error)
    return NextResponse.json(
      { error: 'Failed to check websites' },
      { status: 500 }
    )
  }
}
