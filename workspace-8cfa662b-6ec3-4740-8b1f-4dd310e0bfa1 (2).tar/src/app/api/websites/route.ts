import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const websites = await db.website.findMany({
      orderBy: [
        { status: 'asc' }, // 'down' comes before 'up'
        { lastChecked: 'desc' }
      ],
      take: 50
    })

    return NextResponse.json(websites)
  } catch (error) {
    console.error('Error fetching websites:', error)
    return NextResponse.json(
      { error: 'Failed to fetch websites' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, url, description, checkInterval } = body

    const website = await db.website.create({
      data: {
        name,
        url,
        description,
        checkInterval: checkInterval || 5,
        status: 'unknown',
        uptime: 0,
        isActive: true
      }
    })

    return NextResponse.json(website, { status: 201 })
  } catch (error) {
    console.error('Error creating website:', error)
    return NextResponse.json(
      { error: 'Failed to create website' },
      { status: 500 }
    )
  }
}
