'use client'

import { useEffect, useState } from 'react'
import { Sidebar } from '@/components/sidebar'
import { StatsCard } from '@/components/dashboard/stats-card'
import { WebsiteStatus } from '@/components/dashboard/website-status'
import { RecentTasks } from '@/components/dashboard/recent-tasks'
import { RecentAlerts } from '@/components/dashboard/recent-alerts'
import {
  DollarSign,
  Wrench,
  Globe,
  FolderKanban,
  Users,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
} from 'lucide-react'

interface DashboardStats {
  totalMonthlyCosts: number
  activeTools: number
  websitesUp: number
  websitesDown: number
  openTasks: number
  overdueTasks: number
  completedTasks: number
  newLeads: number
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats>({
    totalMonthlyCosts: 0,
    activeTools: 0,
    websitesUp: 0,
    websitesDown: 0,
    openTasks: 0,
    overdueTasks: 0,
    completedTasks: 0,
    newLeads: 0,
  })

  const [websites, setWebsites] = useState<any[]>([])
  const [tasks, setTasks] = useState<any[]>([])
  const [alerts, setAlerts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)

      // Fetch dashboard stats
      const statsRes = await fetch('/api/dashboard/stats')
      if (statsRes.ok) {
        const statsData = await statsRes.json()
        setStats(statsData)
      }

      // Fetch websites
      const websitesRes = await fetch('/api/websites')
      if (websitesRes.ok) {
        const websitesData = await websitesRes.json()
        setWebsites(websitesData)
      }

      // Fetch tasks
      const tasksRes = await fetch('/api/tasks?limit=10')
      if (tasksRes.ok) {
        const tasksData = await tasksRes.json()
        setTasks(tasksData)
      }

      // Fetch alerts
      const alertsRes = await fetch('/api/alerts?limit=10')
      if (alertsRes.ok) {
        const alertsData = await alertsRes.json()
        setAlerts(alertsData)
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="flex items-center justify-center h-[calc(100vh-3rem)]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading dashboard...</p>
            </div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1">
        <div className="p-6">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Welcome back! Here's what's happening with your operations.
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatsCard
              title="Total Monthly Costs"
              value={`$${stats.totalMonthlyCosts.toLocaleString()}`}
              icon={DollarSign}
              trend={{ value: 12, isPositive: false }}
              description="This month"
              iconClassName="bg-red-100 text-red-700"
            />
            <StatsCard
              title="Active Tools & Licenses"
              value={stats.activeTools}
              icon={Wrench}
              trend={{ value: 8, isPositive: true }}
              iconClassName="bg-blue-100 text-blue-700"
            />
            <StatsCard
              title="Open Tasks"
              value={stats.openTasks}
              icon={FolderKanban}
              description={`${stats.overdueTasks} overdue`}
              iconClassName="bg-purple-100 text-purple-700"
            />
            <StatsCard
              title="New Leads"
              value={stats.newLeads}
              icon={Users}
              trend={{ value: 15, isPositive: true }}
              iconClassName="bg-green-100 text-green-700"
            />
          </div>

          {/* Secondary Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatsCard
              title="Websites Online"
              value={stats.websitesUp}
              icon={CheckCircle}
              description={`Total: ${stats.websitesUp + stats.websitesDown}`}
              iconClassName="bg-green-100 text-green-700"
            />
            <StatsCard
              title="Websites Offline"
              value={stats.websitesDown}
              icon={AlertTriangle}
              iconClassName="bg-red-100 text-red-700"
            />
            <StatsCard
              title="Completed Tasks"
              value={stats.completedTasks}
              icon={TrendingUp}
              iconClassName="bg-blue-100 text-blue-700"
            />
            <StatsCard
              title="Active Projects"
              value={5}
              icon={Globe}
              iconClassName="bg-orange-100 text-orange-700"
            />
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column */}
            <div className="lg:col-span-2 space-y-6">
              <WebsiteStatus websites={websites} />
              <RecentTasks tasks={tasks} />
            </div>

            {/* Right Column */}
            <div>
              <RecentAlerts alerts={alerts} />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
