'use client'

import { useEffect, useState } from 'react'
import { Sidebar } from '@/components/sidebar'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Plus,
  MoreHorizontal,
  Pencil,
  Trash2,
  Key,
  TrendingUp,
  Wrench,
  RefreshCw,
  Globe,
  Clock,
  AlertTriangle,
} from 'lucide-react'
import { toast } from 'sonner'

interface Tool {
  id: string
  name: string
  description?: string
  category: string
  apiKey?: string
  apiEndpoint?: string
  costMonthly?: number
  costYearly?: number
  currency: string
  renewalDate?: string
  expiryDate?: string
  status: string
  usageLimit?: number
  currentUsage?: number
  ownerUserId?: string
  notes?: string
  createdAt: string
  updatedAt: string
  owner?: {
    id: string
    name: string
    email: string
  }
  apiKeys?: any[]
}

export default function ToolsPage() {
  const [tools, setTools] = useState<Tool[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [apiKeyDialogOpen, setApiKeyDialogOpen] = useState(false)
  const [editingTool, setEditingTool] = useState<Tool | null>(null)
  const [selectedToolForApiKey, setSelectedToolForApiKey] = useState<Tool | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'api',
    apiKey: '',
    apiEndpoint: '',
    costMonthly: '',
    costYearly: '',
    currency: 'USD',
    renewalDate: '',
    expiryDate: '',
    status: 'active',
    usageLimit: '',
    currentUsage: '',
    ownerUserId: '',
    notes: '',
  })
  const [apiKeyForm, setApiKeyForm] = useState({
    name: '',
    keyValue: '',
  })

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [toolsRes, usersRes] = await Promise.all([
        fetch('/api/tools/full'),
        fetch('/api/users'),
      ])

      if (toolsRes.ok) {
        const toolsData = await toolsRes.json()
        setTools(toolsData)
      }

      if (usersRes.ok) {
        const usersData = await usersRes.json()
        setUsers(usersData)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
      toast.error('Failed to load data')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const url = editingTool ? `/api/tools/${editingTool.id}` : '/api/tools/full'
      const method = editingTool ? 'PATCH' : 'POST'

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          costMonthly: formData.costMonthly ? parseFloat(formData.costMonthly) : null,
          costYearly: formData.costYearly ? parseFloat(formData.costYearly) : null,
          renewalDate: formData.renewalDate || null,
          expiryDate: formData.expiryDate || null,
          usageLimit: formData.usageLimit ? parseInt(formData.usageLimit) : null,
          currentUsage: formData.currentUsage ? parseInt(formData.currentUsage) : null,
          ownerUserId: formData.ownerUserId || null,
        }),
      })

      if (response.ok) {
        toast.success(editingTool ? 'Tool updated successfully' : 'Tool created successfully')
        setDialogOpen(false)
        resetForm()
        fetchData()
      } else {
        toast.error('Failed to save tool')
      }
    } catch (error) {
      console.error('Error saving tool:', error)
      toast.error('Failed to save tool')
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this tool? This will also delete all associated data.')) return

    try {
      const response = await fetch(`/api/tools/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        toast.success('Tool deleted successfully')
        fetchData()
      } else {
        toast.error('Failed to delete tool')
      }
    } catch (error) {
      console.error('Error deleting tool:', error)
      toast.error('Failed to delete tool')
    }
  }

  const handleEdit = (tool: Tool) => {
    setEditingTool(tool)
    setFormData({
      name: tool.name,
      description: tool.description || '',
      category: tool.category,
      apiKey: tool.apiKey || '',
      apiEndpoint: tool.apiEndpoint || '',
      costMonthly: tool.costMonthly?.toString() || '',
      costYearly: tool.costYearly?.toString() || '',
      currency: tool.currency,
      renewalDate: tool.renewalDate ? tool.renewalDate.split('T')[0] : '',
      expiryDate: tool.expiryDate ? tool.expiryDate.split('T')[0] : '',
      status: tool.status,
      usageLimit: tool.usageLimit?.toString() || '',
      currentUsage: tool.currentUsage?.toString() || '',
      ownerUserId: tool.ownerUserId || '',
      notes: tool.notes || '',
    })
    setDialogOpen(true)
  }

  const handleAddApiKey = (tool: Tool) => {
    setSelectedToolForApiKey(tool)
    setApiKeyForm({ name: '', keyValue: '' })
    setApiKeyDialogOpen(true)
  }

  const handleSaveApiKey = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedToolForApiKey) return

    try {
      const response = await fetch('/api/api-keys', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...apiKeyForm,
          toolId: selectedToolForApiKey.id,
        }),
      })

      if (response.ok) {
        toast.success('API key added successfully')
        setApiKeyDialogOpen(false)
        fetchData()
      } else {
        toast.error('Failed to add API key')
      }
    } catch (error) {
      console.error('Error adding API key:', error)
      toast.error('Failed to add API key')
    }
  }

  const resetForm = () => {
    setEditingTool(null)
    setFormData({
      name: '',
      description: '',
      category: 'api',
      apiKey: '',
      apiEndpoint: '',
      costMonthly: '',
      costYearly: '',
      currency: 'USD',
      renewalDate: '',
      expiryDate: '',
      status: 'active',
      usageLimit: '',
      currentUsage: '',
      ownerUserId: '',
      notes: '',
    })
  }

  const getCategoryBadge = (category: string) => {
    const styles: Record<string, string> = {
      api: 'bg-blue-50 text-blue-700 border-blue-200',
      license: 'bg-green-50 text-green-700 border-green-200',
      subscription: 'bg-purple-50 text-purple-700 border-purple-200',
      software: 'bg-orange-50 text-orange-700 border-orange-200',
    }
    return <Badge variant="outline" className={styles[category] || ''}>{category}</Badge>
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      active: 'bg-green-50 text-green-700 border-green-200',
      inactive: 'bg-gray-50 text-gray-700 border-gray-200',
      expired: 'bg-red-50 text-red-700 border-red-200',
    }
    return <Badge variant="outline" className={styles[status] || ''}>{status}</Badge>
  }

  const calculateTotalMonthly = () => {
    return tools
      .filter((t) => t.status === 'active' && t.costMonthly)
      .reduce((sum, tool) => sum + (tool.costMonthly || 0), 0)
  }

  const totalMonthly = calculateTotalMonthly()

  if (loading) {
    return (
      <div className="flex min-h-screen">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="flex items-center justify-center h-[calc(100vh-3rem)]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading tools...</p>
            </div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold">Tools & API Manager</h1>
              <p className="text-muted-foreground mt-1">
                Manage your tools, APIs, licenses, and subscriptions
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={fetchData}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={() => { resetForm(); }}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Tool
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>{editingTool ? 'Edit Tool' : 'Add New Tool'}</DialogTitle>
                    <DialogDescription>
                      {editingTool ? 'Update tool information below.' : 'Add a new tool or service to your inventory.'}
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleSubmit}>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Tool Name *</Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="category">Category *</Label>
                          <Select
                            value={formData.category}
                            onValueChange={(value) => setFormData({ ...formData, category: value })}
                          >
                            <SelectTrigger id="category">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="api">API</SelectItem>
                              <SelectItem value="license">License</SelectItem>
                              <SelectItem value="subscription">Subscription</SelectItem>
                              <SelectItem value="software">Software</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          value={formData.description}
                          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                          rows={2}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="apiEndpoint">API Endpoint</Label>
                          <Input
                            id="apiEndpoint"
                            placeholder="https://api.example.com"
                            value={formData.apiEndpoint}
                            onChange={(e) => setFormData({ ...formData, apiEndpoint: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="apiKey">Default API Key</Label>
                          <Input
                            id="apiKey"
                            type="password"
                            placeholder="Enter API key"
                            value={formData.apiKey}
                            onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="costMonthly">Monthly Cost</Label>
                          <Input
                            id="costMonthly"
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            value={formData.costMonthly}
                            onChange={(e) => setFormData({ ...formData, costMonthly: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="costYearly">Yearly Cost</Label>
                          <Input
                            id="costYearly"
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            value={formData.costYearly}
                            onChange={(e) => setFormData({ ...formData, costYearly: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="currency">Currency</Label>
                          <Select
                            value={formData.currency}
                            onValueChange={(value) => setFormData({ ...formData, currency: value })}
                          >
                            <SelectTrigger id="currency">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="USD">USD</SelectItem>
                              <SelectItem value="EUR">EUR</SelectItem>
                              <SelectItem value="GBP">GBP</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="renewalDate">Renewal Date</Label>
                          <Input
                            id="renewalDate"
                            type="date"
                            value={formData.renewalDate}
                            onChange={(e) => setFormData({ ...formData, renewalDate: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="expiryDate">Expiry Date</Label>
                          <Input
                            id="expiryDate"
                            type="date"
                            value={formData.expiryDate}
                            onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="usageLimit">Usage Limit</Label>
                          <Input
                            id="usageLimit"
                            type="number"
                            placeholder="Unlimited"
                            value={formData.usageLimit}
                            onChange={(e) => setFormData({ ...formData, usageLimit: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="currentUsage">Current Usage</Label>
                          <Input
                            id="currentUsage"
                            type="number"
                            value={formData.currentUsage}
                            onChange={(e) => setFormData({ ...formData, currentUsage: e.target.value })}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="ownerUserId">Owner</Label>
                          <Select
                            value={formData.ownerUserId}
                            onValueChange={(value) => setFormData({ ...formData, ownerUserId: value })}
                          >
                            <SelectTrigger id="ownerUserId">
                              <SelectValue placeholder="Select owner (optional)" />
                            </SelectTrigger>
                            <SelectContent>
                              {users.map((user) => (
                                <SelectItem key={user.id} value={user.id}>
                                  {user.name || user.email}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="status">Status</Label>
                          <Select
                            value={formData.status}
                            onValueChange={(value) => setFormData({ ...formData, status: value })}
                          >
                            <SelectTrigger id="status">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="active">Active</SelectItem>
                              <SelectItem value="inactive">Inactive</SelectItem>
                              <SelectItem value="expired">Expired</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="notes">Notes</Label>
                        <Textarea
                          id="notes"
                          value={formData.notes}
                          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                          rows={2}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">{editingTool ? 'Update' : 'Create'} Tool</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Tools</CardTitle>
                <Wrench className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{tools.length}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {tools.filter((t) => t.status === 'active').length} active
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Monthly Cost</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  ${totalMonthly.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Total tool costs</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">API Endpoints</CardTitle>
                <Globe className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {tools.filter((t) => t.category === 'api').length}
                </div>
                <p className="text-xs text-muted-foreground mt-1">API integrations</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {tools.filter((t) => t.expiryDate && new Date(t.expiryDate) < new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)).length}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Within 30 days</p>
              </CardContent>
            </Card>
          </div>

          {/* Tools Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <Wrench className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No tools found</h3>
                <p className="text-muted-foreground mb-4">
                  Start by adding your first tool or service.
                </p>
                <Button onClick={() => { resetForm(); setDialogOpen(true); }}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Your First Tool
                </Button>
              </div>
            ) : (
              tools.map((tool) => (
                <Card key={tool.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg mb-1">{tool.name}</CardTitle>
                        <div className="flex items-center gap-2 flex-wrap">
                          {getCategoryBadge(tool.category)}
                          {getStatusBadge(tool.status)}
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleEdit(tool)}>
                            <Pencil className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleAddApiKey(tool)}>
                            <Key className="h-4 w-4 mr-2" />
                            Add API Key
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-red-600"
                            onClick={() => handleDelete(tool.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {tool.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2">{tool.description}</p>
                    )}

                    <div className="flex items-center gap-4 text-sm">
                      {tool.costMonthly && (
                        <div>
                          <span className="font-medium">${tool.costMonthly}</span>
                          <span className="text-muted-foreground">/mo</span>
                        </div>
                      )}
                      {tool.usageLimit && (
                        <div className="flex items-center gap-1">
                          <TrendingUp className="h-3 w-3 text-muted-foreground" />
                          <span className="text-muted-foreground">
                            {tool.currentUsage || 0} / {tool.usageLimit}
                          </span>
                        </div>
                      )}
                    </div>

                    {tool.apiEndpoint && (
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Globe className="h-3 w-3" />
                        <span className="truncate">{tool.apiEndpoint}</span>
                      </div>
                    )}

                    {tool.expiryDate && (
                      <div className="flex items-center gap-1 text-sm">
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        <span className={new Date(tool.expiryDate) < new Date() ? 'text-red-600' : 'text-muted-foreground'}>
                          Expires: {new Date(tool.expiryDate).toLocaleDateString()}
                        </span>
                      </div>
                    )}

                    {tool.expiryDate && new Date(tool.expiryDate) < new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) && (
                      <div className="flex items-center gap-1 text-sm text-orange-600 bg-orange-50 p-2 rounded">
                        <AlertTriangle className="h-3 w-3" />
                        <span>Expiring soon</span>
                      </div>
                    )}

                    {tool.apiKeys && tool.apiKeys.length > 0 && (
                      <div className="flex items-center gap-2 text-sm">
                        <Key className="h-3 w-3 text-muted-foreground" />
                        <span className="text-muted-foreground">{tool.apiKeys.length} API key(s)</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </main>

      {/* API Key Dialog */}
      <Dialog open={apiKeyDialogOpen} onOpenChange={setApiKeyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add API Key</DialogTitle>
            <DialogDescription>
              Add a new API key for {selectedToolForApiKey?.name}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSaveApiKey}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="apiKeyName">Key Name *</Label>
                <Input
                  id="apiKeyName"
                  placeholder="e.g., Production Key"
                  value={apiKeyForm.name}
                  onChange={(e) => setApiKeyForm({ ...apiKeyForm, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="apiKeyValue">API Key Value *</Label>
                <Input
                  id="apiKeyValue"
                  type="password"
                  placeholder="Enter the API key"
                  value={apiKeyForm.keyValue}
                  onChange={(e) => setApiKeyForm({ ...apiKeyForm, keyValue: e.target.value })}
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setApiKeyDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">Save API Key</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
