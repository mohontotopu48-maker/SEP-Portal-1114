'use client'

import { useEffect, useState } from 'react'
import { Sidebar } from '@/components/sidebar'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Plus,
  MoreHorizontal,
  Pencil,
  Trash2,
  Globe,
  CheckCircle2,
  XCircle,
  Clock,
  RefreshCw,
  AlertTriangle,
  TrendingUp,
} from 'lucide-react'
import { toast } from 'sonner'
import { format } from 'date-fns'

interface Website {
  id: string
  name: string
  url: string
  description?: string
  status: 'up' | 'down' | 'unknown'
  uptime: number
  sslValid: boolean
  sslExpiry?: string
  lastChecked?: string
  lastUp?: string
  lastDown?: string
  isActive: boolean
  checkInterval: number
  createdAt: string
  updatedAt: string
}

export default function WebsitesPage() {
  const [websites, setWebsites] = useState<Website[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingWebsite, setEditingWebsite] = useState<Website | null>(null)
  const [checking, setChecking] = useState<Set<string>>(new Set())
  const [formData, setFormData] = useState({
    name: '',
    url: '',
    description: '',
    checkInterval: 5,
  })

  useEffect(() => {
    fetchWebsites()
    // Set up auto-refresh every 30 seconds
    const interval = setInterval(fetchWebsites, 30000)
    return () => clearInterval(interval)
  }, [])

  const fetchWebsites = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/websites')
      if (response.ok) {
        const data = await response.json()
        setWebsites(data)
      }
    } catch (error) {
      console.error('Error fetching websites:', error)
      toast.error('Failed to load websites')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const url = editingWebsite ? `/api/websites/${editingWebsite.id}` : '/api/websites'
      const method = editingWebsite ? 'PATCH' : 'POST'

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          checkInterval: parseInt(formData.checkInterval.toString()),
        }),
      })

      if (response.ok) {
        toast.success(editingWebsite ? 'Website updated successfully' : 'Website added successfully')
        setDialogOpen(false)
        resetForm()
        fetchWebsites()
      } else {
        toast.error('Failed to save website')
      }
    } catch (error) {
      console.error('Error saving website:', error)
      toast.error('Failed to save website')
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this website? This will also delete all monitoring history.')) return

    try {
      const response = await fetch(`/api/websites/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        toast.success('Website deleted successfully')
        fetchWebsites()
      } else {
        toast.error('Failed to delete website')
      }
    } catch (error) {
      console.error('Error deleting website:', error)
      toast.error('Failed to delete website')
    }
  }

  const handleCheck = async (website: Website) => {
    try {
      setChecking(prev => new Set(prev).add(website.id))

      const response = await fetch(`/api/websites/${website.id}/check`, {
        method: 'POST',
      })

      if (response.ok) {
        toast.success(`Checked ${website.name} successfully`)
        fetchWebsites()
      } else {
        toast.error('Failed to check website')
      }
    } catch (error) {
      console.error('Error checking website:', error)
      toast.error('Failed to check website')
    } finally {
      setChecking(prev => {
        const newSet = new Set(prev)
        newSet.delete(website.id)
        return newSet
      })
    }
  }

  const handleCheckAll = async () => {
    const activeWebsites = websites.filter(w => w.isActive)
    if (activeWebsites.length === 0) {
      toast.info('No active websites to check')
      return
    }

    try {
      setChecking(new Set(activeWebsites.map(w => w.id)))

      const response = await fetch('/api/websites/check-all', {
        method: 'POST',
      })

      if (response.ok) {
        toast.success('All websites checked successfully')
        fetchWebsites()
      } else {
        toast.error('Failed to check all websites')
      }
    } catch (error) {
      console.error('Error checking websites:', error)
      toast.error('Failed to check websites')
    } finally {
      setChecking(new Set())
    }
  }

  const handleEdit = (website: Website) => {
    setEditingWebsite(website)
    setFormData({
      name: website.name,
      url: website.url,
      description: website.description || '',
      checkInterval: website.checkInterval,
    })
    setDialogOpen(true)
  }

  const resetForm = () => {
    setEditingWebsite(null)
    setFormData({
      name: '',
      url: '',
      description: '',
      checkInterval: 5,
    })
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'up':
        return <CheckCircle2 className="h-5 w-5 text-green-600" />
      case 'down':
        return <XCircle className="h-5 w-5 text-red-600" />
      default:
        return <Clock className="h-5 w-5 text-yellow-600" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'up':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Online</Badge>
      case 'down':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Offline</Badge>
      default:
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Unknown</Badge>
    }
  }

  const calculateStats = () => {
    const total = websites.length
    const up = websites.filter(w => w.status === 'up').length
    const down = websites.filter(w => w.status === 'down').length
    const avgUptime = total > 0
      ? websites.reduce((sum, w) => sum + w.uptime, 0) / total
      : 0

    return { total, up, down, avgUptime }
  }

  const stats = calculateStats()

  if (loading) {
    return (
      <div className="flex min-h-screen">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="flex items-center justify-center h-[calc(100vh-3rem)]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading websites...</p>
            </div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold">Website & Server Monitor</h1>
              <p className="text-muted-foreground mt-1">
                Monitor website uptime, SSL certificates, and server health
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleCheckAll} disabled={checking.size > 0}>
                {checking.size > 0 ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Checking...
                  </>
                ) : (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Check All
                  </>
                )}
              </Button>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={() => { resetForm(); }}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Website
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{editingWebsite ? 'Edit Website' : 'Add New Website'}</DialogTitle>
                    <DialogDescription>
                      {editingWebsite
                        ? 'Update website monitoring settings.'
                        : 'Add a new website to monitor for uptime and health.'}
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleSubmit}>
                    <div className="grid gap-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Website Name *</Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="url">URL *</Label>
                        <Input
                          id="url"
                          placeholder="https://example.com"
                          value={formData.url}
                          onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          value={formData.description}
                          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                          rows={2}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="checkInterval">Check Interval (minutes)</Label>
                        <Input
                          id="checkInterval"
                          type="number"
                          min="1"
                          value={formData.checkInterval}
                          onChange={(e) => setFormData({ ...formData, checkInterval: parseInt(e.target.value) })}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">{editingWebsite ? 'Update' : 'Add'} Website</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Websites</CardTitle>
                <Globe className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stats.up} online, {stats.down} offline
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Online</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{stats.up}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stats.total > 0 ? Math.round((stats.up / stats.total) * 100) : 0}% of total
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Offline</CardTitle>
                <XCircle className="h-4 w-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{stats.down}</div>
                <p className="text-xs text-muted-foreground mt-1">Needs attention</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg Uptime</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats.avgUptime.toFixed(2)}%
                </div>
                <p className="text-xs text-muted-foreground mt-1">Across all websites</p>
              </CardContent>
            </Card>
          </div>

          {/* Websites Table */}
          <Card>
            <CardHeader>
              <CardTitle>All Websites</CardTitle>
              <CardDescription>
                Monitor uptime, SSL certificates, and response times
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Status</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>URL</TableHead>
                      <TableHead>Uptime</TableHead>
                      <TableHead>SSL</TableHead>
                      <TableHead>Last Checked</TableHead>
                      <TableHead>Check Interval</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {websites.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                          No websites found. Click "Add Website" to start monitoring.
                        </TableCell>
                      </TableRow>
                    ) : (
                      websites.map((website) => (
                        <TableRow key={website.id} className={website.status === 'down' ? 'bg-red-50/50' : ''}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {getStatusIcon(website.status)}
                              {getStatusBadge(website.status)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{website.name}</p>
                              {website.description && (
                                <p className="text-sm text-muted-foreground line-clamp-1">
                                  {website.description}
                                </p>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <a
                              href={website.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm text-blue-600 hover:underline"
                            >
                              {website.url}
                            </a>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span className={`font-medium ${website.uptime >= 99 ? 'text-green-600' : website.uptime >= 95 ? 'text-yellow-600' : 'text-red-600'}`}>
                                {website.uptime.toFixed(2)}%
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {website.sslValid ? (
                                <CheckCircle2 className="h-4 w-4 text-green-600" />
                              ) : (
                                <XCircle className="h-4 w-4 text-red-600" />
                              )}
                              {website.sslExpiry ? (
                                <span className="text-sm">
                                  {format(new Date(website.sslExpiry), 'MMM d, yyyy')}
                                </span>
                              ) : (
                                <span className="text-sm text-muted-foreground">-</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            {website.lastChecked ? (
                              <div className="flex items-center gap-1 text-sm">
                                <Clock className="h-3 w-3 text-muted-foreground" />
                                <span>{format(new Date(website.lastChecked), 'MMM d, HH:mm')}</span>
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              Every {website.checkInterval} min
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center gap-2 justify-end">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleCheck(website)}
                                disabled={checking.has(website.id)}
                              >
                                {checking.has(website.id) ? (
                                  <RefreshCw className="h-4 w-4 animate-spin" />
                                ) : (
                                  <RefreshCw className="h-4 w-4" />
                                )}
                              </Button>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onClick={() => handleEdit(website)}>
                                    <Pencil className="h-4 w-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    className="text-red-600"
                                    onClick={() => handleDelete(website.id)}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
